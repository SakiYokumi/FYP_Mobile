// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyA9W2fK5e77X6kyAcYE9FLlFMG7w48Yzf8",
  authDomain: "demo1-438d3.firebaseapp.com",
  databaseURL: "https://demo1-438d3-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "demo1-438d3",
  storageBucket: "demo1-438d3.appspot.com",
  messagingSenderId: "391275199949",
  appId: "1:391275199949:web:3600eb170eeef962bf1884",
  measurementId: "G-TGGT7QGDL7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);