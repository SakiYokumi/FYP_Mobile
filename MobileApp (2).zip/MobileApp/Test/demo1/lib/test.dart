

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
class Testing extends StatefulWidget {
  const Testing({super.key});

  @override
  State<Testing> createState() => _TestingState();
}

class _TestingState extends State<Testing> {

  var test = ['asd','sadas','asdasd'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Testing"),
      ),

      body: Container(
        child: ElevatedButton(
          onPressed: (){
            insert();
          },
          child: Text("Insert"),
        )
      )
    );
  }
  
  void insert() async{
    CollectionReference ref = FirebaseFirestore.instance.collection('testing');
    await ref.add(
      {
        'data': test,
        'Id': 1,
      }
    ).then((value) => print("Added"));

  }
  

}