import 'dart:async';

import 'package:demo1/welcome.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}


class _SplashScreenState extends State<SplashScreen> {
  
  @override
  void initState() {
    Timer(const Duration(seconds: 3), ()=>Navigator.push(context, CupertinoPageRoute(builder: (_)=>const Welcome())));
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.only(left: 50),
            child: Image.asset(
              "assets/images/HRMsLogo.jpg",
              fit: BoxFit.cover,
              alignment: Alignment.center,
            ),
          )
        ],
      )
    );

  }
}

