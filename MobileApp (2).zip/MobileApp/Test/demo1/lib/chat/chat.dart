import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chatdetail.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

class Chat extends StatefulWidget {
  const Chat({super.key});

  @override
  State<Chat> createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  var currentUser = FirebaseAuth.instance.currentUser;
  var _user = [];
  int _selectedIndex = 2;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    initializeDateFormatting();
    fetchChat();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Chat'),
      ),
      body: SafeArea(
        //Type your code here   
        child: Column(
          children: [
            Padding(
              // ignore: prefer_const_constructors
              padding: EdgeInsets.all(8),
              child: TextFormField(
                readOnly: true,
                //onTap: () => Navigator.push(context, CupertinoPageRoute(builder: (_)=>const Search())),
                decoration: const InputDecoration(
                  fillColor: Colors.white,
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(0)),
                    borderSide: BorderSide(
                      color: Colors.blue
                    )
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(0)),
                      borderSide: BorderSide(
                          color: Colors.grey
                      )
                  ),
                  hintText: "Search contacts",
                  hintStyle: TextStyle(fontSize: 15.0),
                ),
              ),
            ),

            Expanded(
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(25),
                    topRight: Radius.circular(25),
                  )
                ),
                child: _user.isNotEmpty ? buildChat(): const Center(child: Text('Currently contact list is empty'),)
              ) 
            ),
          ],
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
  
  buildChat() {
    var i = 0;
    return ListView.builder(
      itemCount: _user.length,
      itemBuilder: (context, index){  
        return SizedBox(            
          height: 100,
          child: ListTile(
            onTap: (){
              //direct to chat detail
              Navigator.push(context, MaterialPageRoute(builder: (context)=> ChatDetail(_user[index])));
            },
            leading: CircleAvatar(
              backgroundImage: NetworkImage(_user[index]['img']),
              radius: 28,
            ),
            title: Text("${_user[index]['name']}", style: const TextStyle(fontWeight: FontWeight.bold)),           
            subtitle: i < msg.length ? Text( '${msg[i]['by']} : ${msg[i++]['content']}'): null,
            trailing: Text("${_user[index]['date']}", style: const TextStyle(color: Colors.grey),),
          ),
        );
        
      },
    );
  }
  
  var msg = [];
  void fetchChat() async {
    DateTime dt;
    QuerySnapshot qn = await FirebaseFirestore.instance.collection('Chat')
    .where("FromUser", isEqualTo: currentUser!.email)
    .get();
    
    setState(() { 
      for(int i = 0; i < qn.docs.length; i++){
        var id = qn.docs[i]['ChatID'];
        dt = (qn.docs[i]["lastChat"] as Timestamp).toDate();
        var time = DateFormat('dd/MM/yyyy').format(dt);     
        _user.add({
          "ChatID": id,
          "img": qn.docs[i]['receiverImg'],
          "name": qn.docs[i]['OwnerUserName'],
          "date": time,
        });
      }
    });
    
    
    QuerySnapshot qn2 = await FirebaseFirestore.instance.collection('Chat')
    .where("ToOwner", isEqualTo: currentUser!.email)
    .get();
    setState(() {
        for(int i = 0; i < qn2.docs.length; i++){
        dt = (qn2.docs[i]["lastChat"] as Timestamp).toDate();
        var time = DateFormat('dd/MM/yyyy').format(dt);   
        _user.add({
          "ChatID": qn2.docs[i]['ChatID'],
          "img": qn2.docs[i]['senderImg'],
          "name": qn2.docs[i]['ChatUserName'],       
          "date": time,
        });
      }
    });
    
    for(int i = 0; i < _user.length; i++){
      var id = _user[i]['ChatID'];
      QuerySnapshot qn3 = await FirebaseFirestore.instance.collection('ChatDetail')
      .where('ChatID', isEqualTo: id)
      .get();   
      // setState(() {
      //   if(qn3.docs.isNotEmpty){
      //     msg.add({
      //       'content': qn3.docs[qn.docs.length -1]['Content'] ?? "",
      //       'by': qn3.docs[qn.docs.length -1]['by']
      //     });
      //   }else{
      //     msg.add({
      //       // 'content': "",
      //       // 'by': ""
      //     });
      //   }
        
      // });
    }
  }
}