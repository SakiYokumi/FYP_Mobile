import 'dart:convert';
import 'dart:math';
import 'package:demo1/chat/mymessage.dart';
import 'package:demo1/chat/mymessage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ChatDetail extends StatefulWidget {
  ChatDetail(this._chat, {super.key});
  var _chat;

  @override
  State<ChatDetail> createState() => _ChatDetailState();
}

class _ChatDetailState extends State<ChatDetail> {
  final messageController = TextEditingController();
  var by;
  final list = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat'),
      ),
      body: Column(
          children: [
            Expanded(
              child:SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  StreamBuilder(
                      stream: FirebaseFirestore.instance
                          .collection('ChatDetail')
                          .where('ChatID', isEqualTo: widget._chat['ChatID'])
                          .snapshots(),
                      // initialData: initialData,
                      builder:
                          (BuildContext context, AsyncSnapshot snapshot) {
                        if (snapshot.hasError) {
                          return Center(
                            child: Text("Something went wrong"),
                          );
                        }
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return Center(
                            child: Text("Loading"),
                          );
                        }
                        return ListView.builder(
                            shrinkWrap: true,
                            itemCount: snapshot.data.docs.length,
                            // reverse: true,
                            physics: BouncingScrollPhysics(),
                            itemBuilder: (context, index) {
                              bool isMe =
                                  snapshot.data.docs[index]['by'] == by;
                              // return Text('Text');

                            return MyMessage(message: snapshot.data.docs[index]['Content'], isMe: isMe);
                              
                            });
                      }),
                ],
              ),
            ), 
              )
          ],
        ),
      
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(10),
        //  alignment: Alignment.center,
        child: TextFormField(
          // obscureText: _isObscured1,
          // onChanged: (val){
          //   setState(() => password = val);
          // },
          validator: (val) => val!.length < 6 ? 'Enter a message' : null,
          controller: messageController,
          style: TextStyle(
            fontSize: 24,
            color: Colors.blue,
            fontWeight: FontWeight.w600,
          ),
          decoration: InputDecoration(
              labelText: "Type your message here",
              focusColor: Colors.white,
              border: OutlineInputBorder(),
              prefixIcon: Icon(
                Icons.message,
                color: Colors.grey,
              ),
              suffixIcon: IconButton(
                padding: const EdgeInsetsDirectional.only(end: 12.0),
                onPressed: () async {
                  print(widget._chat);
                  var currentUser = FirebaseAuth.instance.currentUser;
                  var email = currentUser!.email;
                  QuerySnapshot userdata = await FirebaseFirestore.instance
                      .collection("UserAcc")
                      .where('email', isEqualTo: email)
                      .get();

                  by = userdata.docs[0]['username'];
                  var db = FirebaseFirestore.instance;
                  QuerySnapshot qn = await db.collection("ChatDetail").get();
                  List<DocumentSnapshot> _doc = qn.docs;
                  //print("${_doc.length + 1} records");
                  int num = _doc.length + 1;
                  CollectionReference ref = db.collection('ChatDetail');
                  await ref.doc(num.toString()).set({
                    "ChatID": widget._chat['ChatID'] ?? "",
                    "Content": messageController.text,
                    "DetailID": num,
                    "isDeleted": "no",
                    "PostedOn": Timestamp.now(),
                    "by": by,
                  }).then((value) => Fluttertoast.showToast(msg: "Message Sent")
                      .catchError((error) => Fluttertoast.showToast(
                          msg: "Oops Something went wrong")));
                  // Navigator.push(context, MaterialPageRoute(builder: (context) => const PropertyMain()));
                },
                icon: Icon(Icons.send),
              ),
              focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                    width: 1.0,
                    color: Colors.blue,
                  ),
                  borderRadius: BorderRadius.circular(10)),
              fillColor: Colors.grey,
              hintStyle: TextStyle(
                color: Colors.grey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
                fontFamily: "verdana_regular",
              ),

              //create label
              labelStyle: TextStyle(
                color: Colors.grey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
                fontFamily: "verdana_regular",
              )),
        ),
      ),
    );
  }
}
