// import 'package:cloud_firestore/cloud_firestore.dart';

// class ChatApi {

//   static Future uploadMessage (String by, String Content) async
//   final refContent =

//   FirebaseFirestore.instance.collection('ChatDetail/$by/Content');

//   final newContent = Content(
//     content:content,
//     createdAt: DateTime.now(),

//   )

// }