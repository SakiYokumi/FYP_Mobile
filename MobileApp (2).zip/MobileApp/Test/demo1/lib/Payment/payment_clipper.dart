import 'package:flutter/material.dart';

class PaymentHeaderClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();

    double radius = 24;

    path.moveTo(0, radius);

    path.quadraticBezierTo(0, 0, radius, 0);

    path.lineTo(size.width, 0);
    path.lineTo(size.width, size.height);
    path.lineTo(radius / 2, size.height);

    path.quadraticBezierTo(
        radius / 2, size.height - radius / 2, 0, size.height - radius / 2);

    path.close();

    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => true;
}

class PaymentContentClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    // TODO: implement getClip
    throw UnimplementedError();
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => true;
}
