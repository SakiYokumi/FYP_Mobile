import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:demo1/Payment/folder_clipper.dart';
// import 'package:demo1/Payment/payment_clipper.dart';
import 'package:demo1/Payment/paymentmethod.dart';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


Color defaultColor = Colors.purple;

class Payment extends StatefulWidget {
  Payment(this._detail, {super.key});
  var _detail; //ret widget._owner
  @override
  State<Payment> createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {
  String currentDate = DateFormat('yyyy-MM-dd').format(DateTime.now());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("Invoice")),
        body: ClipPath(
          
          child: Container(
            color: Theme.of(context).scaffoldBackgroundColor,
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            padding: const EdgeInsets.only(top: 24),
            child: Column(
              children: [
                _buildHeader(context),
                _buildContent(context),
                const Expanded(child: SizedBox.shrink()),
                _buildActionButton(context),
              ],
            ),
          ),
        ));
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Payee Email",
                style: Theme.of(context).textTheme.bodyText2,
              ),
              Text("Tenant",
                  style: Theme.of(context).textTheme.headline6!.copyWith(
                        color: Colors.purple,
                      )),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Total Amount",
                style: Theme.of(context).textTheme.bodyText2,
              ),
              Text("RM${widget._detail['price']}",
                  style: Theme.of(context).textTheme.headline6!.copyWith(
                        color: Colors.purple,
                      )),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildContent(BuildContext context) {
    return Column(
      children: [
        Container(
          color: Colors.blue.shade400,
          height: 100,
          padding: const EdgeInsets.all(24),
          child: Row(
            children: [
              const Icon(
                Icons.monetization_on,
                color: Colors.black54,
              ),
              Text(
                "Invoice",
                style: Theme.of(context).textTheme.headline4,
              ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  " ",
                  style: Theme.of(context).textTheme.bodyText2,
                ),
                const Icon(
                  Icons.receipt,
                  color: Colors.redAccent,
                ),
                Text(
                  "  Payer Email",
                  style: Theme.of(context).textTheme.bodyText2,
                ),
                Text(" TEmail@.gmail.com",
                    style: Theme.of(context).textTheme.headline6!.copyWith(
                          color: Colors.purple,
                        )),
                Text(
                  " ",
                  style: Theme.of(context).textTheme.bodyText2,
                ),
                const Icon(
                  Icons.insert_comment_sharp,
                  color: Colors.blue,
                ),
                Text(
                  "Item Details",
                  style: Theme.of(context).textTheme.bodyText2,
                ),
                Text(
                  " ",
                  style: Theme.of(context).textTheme.bodyText2,
                ),
                Text(" Rental Fee",
                    style: Theme.of(context).textTheme.headline6!.copyWith(
                          color: Colors.purple,
                        )),
                Text(
                  " ",
                  style: Theme.of(context).textTheme.bodyText2,
                ),
                // Text(" Deposit",
                //     style: Theme.of(context).textTheme.headline6!.copyWith(
                //           color: Colors.purple,
                //         )),
              ],
            ),
            Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      " ",
                      style: Theme.of(context).textTheme.bodyText2,
                    ),
                    const Icon(
                      Icons.date_range,
                      color: Colors.redAccent,
                    ),
                    Container(
                      child: Text(
                        "  Invoice Date",
                        style: Theme.of(context).textTheme.bodyText2,
                      ),
                    ),
                    Text("$currentDate",
                        style: Theme.of(context).textTheme.headline6!.copyWith(
                              color: Colors.purple,
                            )),
                    Text(
                      " ",
                      style: Theme.of(context).textTheme.bodyText2,
                    ),
                    const Icon(
                      Icons.monetization_on_outlined,
                      color: Colors.blue,
                    ),
                    Column(
                      children: [
                        Text(
                          "Price",
                          style: Theme.of(context).textTheme.bodyText2,
                        ),
                      ],
                    ),
                    Text(
                      " ",
                      style: Theme.of(context).textTheme.bodyText2,
                    ),
                    // rental fees
                    Text("MYR 900.00",
                        style: Theme.of(context).textTheme.headline6!.copyWith(
                              color: Colors.purple,
                            )),
                    Text(
                      " ",
                      style: Theme.of(context).textTheme.bodyText2,
                    ),
                    // Text("MYR 100.00",
                    //     style: Theme.of(context).textTheme.headline6!.copyWith(
                    //           color: Colors.purple,
                    //         )),
                  ],
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButton(BuildContext context) {
    return Row(
      children: [
        Expanded(
            child: Container(
          color: Colors.orangeAccent,
          child: TextButton(
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => PaymentMethod()));
              //direct to payment method
            },
            child: Text(
              "Proceed",
              style: TextStyle(color: defaultColor),
            ),
          ),
        ))
      ],
    );
  }
}
