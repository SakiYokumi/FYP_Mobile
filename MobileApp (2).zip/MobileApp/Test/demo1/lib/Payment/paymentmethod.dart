import 'dart:convert';

import 'package:demo1/Payment/payment.dart';
import 'package:demo1/Payment/success.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:pay/pay.dart';

class PaymentMethod extends StatefulWidget {
  const PaymentMethod({super.key});

  @override
  _PaymentMethod createState() => _PaymentMethod();
}

class _PaymentMethod extends State<PaymentMethod> {
  var kPrimaryColor = Color(0xFFFF8F00);
  var KDarkColor = Color(0xDD000000);
  int value = 0;
  final paymentLables = [
    'Credit card / Debit card',
    // 'Cash',
    // 'E-Wallet',
  ];
  final paymentIcons = [
    Icons.credit_card,
    Icons.attach_money,
    Icons.account_balance_wallet,
  ];
  final _paymentItems = [
    PaymentItem(
      // retrieve price from the previous page
      //
      //
      //
      //
      label: 'Total',
      amount: '99.99',
      status: PaymentItemStatus.final_price,
    )
  ];

  final Future<PaymentConfiguration> _googlePayConfigFuture =
      PaymentConfiguration.fromAsset('gpay.json');

  void onGooglePayResult(paymentResult) {
    // show the payment result
    //
    //
    //
    //
    //
    //
    //
    //
    //
    print(paymentResult);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Payment Result: $paymentResult"))
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Payment Method'),
      ),
      body: Column(children: [
        Text(
          'Please select your payment method',
          style: TextStyle(
              fontSize: 20,
              color: Colors.purpleAccent,
              fontStyle: FontStyle.italic),
        ),
        Expanded(
          child: ListView.separated(
            itemCount: paymentLables.length,
            itemBuilder: (context, index) {
              return ListTile(
                leading: Radio(
                  activeColor: kPrimaryColor,
                  value: index,
                  groupValue: value,
                  onChanged: (i) => setState(() => value = i!),
                ),
                title: Text(
                  paymentLables[index],
                  style: TextStyle(color: KDarkColor),
                ),
                trailing: Icon(paymentIcons[index]),
              );
            },
            separatorBuilder: ((context, index) {
              return Divider();
            }),
          ),
        ),
        // TextButton(
        //     onPressed: () => Navigator.of(context)
        //         .push(MaterialPageRoute(builder: (context) => Success())),
        //     child: Text(' Proceed To Payment  ',
        //         style: TextStyle(fontSize: 24, color: Colors.white)),
        //     style: ButtonStyle(
        //         backgroundColor: MaterialStateProperty.all<Color>(Colors.blue),
        //         shape: MaterialStateProperty.all<RoundedRectangleBorder>(
        //             RoundedRectangleBorder(
        //           borderRadius: BorderRadius.circular(10.0),
        //           side: BorderSide(color: Colors.blue),
        //         ))))

        // future
        FutureBuilder<PaymentConfiguration>(
            future: _googlePayConfigFuture,
            builder: (context, snapshot) => snapshot.hasData
                ? GooglePayButton(
                    paymentConfiguration: snapshot.data!,
                    paymentItems: _paymentItems,
                    type: GooglePayButtonType.pay,
                    margin: const EdgeInsets.only(top: 15.0),
                    onPaymentResult: onGooglePayResult,
                    loadingIndicator: const Center(
                      child: CircularProgressIndicator(),
                    ),
                  )
                : const SizedBox.shrink()
                
                ),
                // Fluttertoast.showToast(msg: 'Done');
      ]),
    );
  }
}
