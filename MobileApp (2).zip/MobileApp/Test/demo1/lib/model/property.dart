class Property{
    String? pid;

    set setPid(String id){
      pid = id;
    }

    String? get getID{
      return pid;
    }
}