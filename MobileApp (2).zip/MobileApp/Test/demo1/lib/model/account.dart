class Account{
  String? email;
  String? password;

  Account(
    {
      this.email,
      this.password,
    }
  );

  String? get getPassword{
    return password;
  }

  set setPassword(String? pwd){
    password = pwd;
  }

    String? get getEmail{
    return email;
  }

  set setEmail(String? mail){
    email = mail;
  }
}