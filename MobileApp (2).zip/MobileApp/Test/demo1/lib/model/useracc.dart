class UserAcc {
  final String? uid;
  // final String? username;
  // final String? email;
  // //final String? password; 
  // final int? phone;

  UserAcc(
    {
      this.uid,
      // this.username,
      // this.email,
      // //this.password,
      // this.phone
    }
  );
}