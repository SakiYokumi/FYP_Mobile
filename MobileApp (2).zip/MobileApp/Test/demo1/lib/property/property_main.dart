import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/myproperty.dart';
import 'package:demo1/property/rentedproperty.dart';
import 'package:demo1/property/summary.dart';
import 'package:demo1/user/usermain.dart';
import 'package:flutter/material.dart';

class PropertyMain extends StatefulWidget {
  const PropertyMain({super.key});

  @override
  State<PropertyMain> createState() => _PropertyMainState();
}

class _PropertyMainState extends State<PropertyMain> {
  int _selectedIndex = 1;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.blue[400],
        title: const Text('Property'),
      ),
      body: SingleChildScrollView(
        //Type your code here   
        scrollDirection: Axis.vertical,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            
            Container(
              margin: const EdgeInsets.fromLTRB(0, 20, 0, 00),
              child: const Center(
                child: CircleAvatar(
                  radius: 100,
                  backgroundColor: Colors.black,
                  child: Icon(Icons.home, color: Colors.white,size: 100,),
                ),
              )
            ),

            Container(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
              margin: const EdgeInsets.all(0),
              child: ElevatedButton(
                onPressed: (){
                  Navigator.push(
                    context, 
                    MaterialPageRoute(builder: (context) => const MyProperty()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[400],
                  minimumSize: const Size(100,50),
                  fixedSize: const Size(400, 50)
                ),
                child: const Text('My Property'),         
              ),
            ),

            Container(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
              margin: const EdgeInsets.all(0),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context, 
                    MaterialPageRoute(builder: (context) => const RentedProperty()),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[400],
                  minimumSize: const Size(100,50),
                  fixedSize: const Size(400, 50)
                ),
                child: const Text('Rented Property'),         
              ),
            ),

            Container(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
              margin: const EdgeInsets.all(0),
              child: ElevatedButton(
                onPressed: () async {
                  Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Summary())
                  );
                 
                  // navigate to report page
                  
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green[400],
                  minimumSize: const Size(100,50),
                  fixedSize: const Size(400, 50)
                ),
                child: const Text('My Summary'),         
              ),
            ),

          ]
        ),
        
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}