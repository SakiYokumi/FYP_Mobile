// ignore_for_file: camel_case_types, prefer_const_constructors
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/addimg.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Add_Property extends StatefulWidget {
  const Add_Property({super.key});

  @override
  State<Add_Property> createState() => _Add_PropertyState();
}

class _Add_PropertyState extends State<Add_Property> {
  int _selectedIndex = 1;
  
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }
  final _formKey = GlobalKey<FormState>(); 
  final _nameController = TextEditingController();
  final _postalController = TextEditingController();
  final _cityController = TextEditingController();
  final _stateController = TextEditingController();
  final _houseController = TextEditingController();
  final _buildingNameController = TextEditingController();
  final _roomController = TextEditingController();
  final _bathroomController = TextEditingController();
  final _priceController = TextEditingController();
  final _descriptionController = TextEditingController();
  String houseNo = '';
  String name = '';
  String city = "";
  String state = '';
  int postal = 0;
  int room = 0;
  int bathroom = 0;
  int price = 0;
  String buildingName = '';
  String imageUrl1 ="";
  String imageUrl2 = "";
  String imageUrl3 = ""; 
  var value = 0;
   List temp = [];

  @override
  void dispose(){
    _nameController.dispose();
    _postalController.dispose();
    _cityController.dispose();
    _stateController.dispose();
    _houseController.dispose();
    super.dispose();
  }

  var detail = [];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Add Image'),
      ),

      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            children: <Widget>[       
              //building name
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  //validator: (val) => val!.isEmpty ? "Enter House Number" : null,
                  onChanged: (val){
                    setState(() => buildingName = val);
                  },
                  controller: _buildingNameController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Building name (optional)",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //house number
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  validator: (val) => val!.isEmpty ? "Enter House Number" : null,
                  onChanged: (val){
                    setState(() => houseNo = val);
                  },
                  controller: _houseController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "House Number",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),
      
              //street name
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  autofillHints: const [AutofillHints.streetAddressLevel1],
                  validator: (val) => val!.isEmpty ? "Enter a name" : null,
                  onChanged: (val){
                    setState(() => name = val);
                  },
                  controller: _nameController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Street",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    // prefixIcon: const Icon(
                    //   Icons.streetview,
                    //   color: Colors.grey,
                    // ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),
      
              //postal
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  autofillHints: const [AutofillHints.postalCode],
                  keyboardType: TextInputType.number,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the postal";
                    }else if (val.length != 5){
                      return "Postal must be 5 digti";
                    }else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => postal = int.parse(val));
                  },
                  controller: _postalController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Postal/Zip code",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    // prefixIcon: const Icon(
                    //   Icons.person_outline_rounded,
                    //   color: Colors.grey,
                    // ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),
  
              //city
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  autofillHints: const [AutofillHints.addressCity],
                  keyboardType: TextInputType.streetAddress,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the city name";
                    }else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => city = val);
                  },
                  controller: _cityController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "City",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),
  
              //state
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  autofillHints: const {AutofillHints.addressState},
                  keyboardType: TextInputType.streetAddress,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the state name";
                    }else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => state = val);
                  },
                  controller: _stateController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "State",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    // prefixIcon: const Icon(
                    //   Icons.person_outline_rounded,
                    //   color: Colors.grey,
                    // ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //no of room
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  
                  keyboardType: TextInputType.number,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the number of room";
                    }
                    else if(int.parse(val) < 1){
                      return "Room should not be smaller than 1";
                    }
                    else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => room = int.parse(val));
                  },
                  controller: _roomController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Room",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //bathroom
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  
                  keyboardType: TextInputType.number,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the number of bathroom";
                    }
                    else if(int.parse(val) < 1){
                      return "Bathroom should not be smaller than 1";
                    }
                    else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => bathroom = int.parse(val));
                  },
                  controller: _bathroomController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Bathroom",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //price
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  
                  keyboardType: TextInputType.number,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the price";
                    }
                    else if(int.parse(val) < 1){
                      return "Price should not be 0 or smaller than 0";
                    }
                    else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => price = int.parse(val));
                  },
                  controller: _priceController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Price",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //description
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  controller: _descriptionController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Description (optional)",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,
  
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),
  
                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              Container(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                margin: const EdgeInsets.all(0),
                child: ElevatedButton(
                  onPressed: () async {
                    //getID();
                    detail.add(
                      {
                        "address": _houseController.text,
                        "bathroom": _bathroomController.text,
                        "city": _cityController.text,
                        "description": _descriptionController.text,
                        "owned-by": getUser(),
                        // "pid": value,
                        "postal": _postalController.text,
                        "price": _priceController.text,
                        "property-name": _buildingNameController.text,
                        "room":_roomController.text,
                        "state": _stateController.text,
                        "street": _nameController.text
                      }
                    );
                    //print("${detail[0]['address']}, ${detail[0]['owned-by']}");
                    Navigator.push(
                      context, 
                      MaterialPageRoute(builder: (context) => AddImg(detail[0])),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[400],
                    minimumSize: const Size(100,50),
                    fixedSize: const Size(400, 50)
                  ),
                  child: Text('Next'.toUpperCase()),         
                ),
              ),
            ],
          ),
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    ); 
  }
  
  getUser() {
    final user = FirebaseAuth.instance.currentUser;
    return user?.email;
  }
  
 
  // void getID() async{
  //   var db = FirebaseFirestore.instance;
  //   // var ref = db.ref().child("Property");
    
  //   QuerySnapshot qn = await db.collection('Property').get();
  //   List<DocumentSnapshot> _doc = qn.docs;
  // //  setState(() {
  // //    temp.add({
  // //     "pid": qn.docs[0]['pid'],
  // //    });
  // //    value = temp[0]['pid'];
  // //  });
  //  print(_doc.length);
  //  value = _doc.length;
  // //  //value = temp[0]['pid'].toString();
  // }
}