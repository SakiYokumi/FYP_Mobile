import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/myproperty.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class EditProperty extends StatefulWidget {
  //const EditProperty({super.key});
  var _detail;
  EditProperty(this._detail, {super.key});
  @override
  State<EditProperty> createState() => _EditPropertyState();
}

class _EditPropertyState extends State<EditProperty> {
  int _selectedIndex = 1;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  showAlertDialog(BuildContext context, String id) {
  // set up the buttons
  // ignore: unused_local_variable
    Widget cancelButton = TextButton(
      child: const Text("No"),
      onPressed:  () {
        Navigator.of(context).pop();
      },
    );
    Widget continueButton = TextButton(
      child: const Text("Yes"),
      onPressed:  () {
          CollectionReference ref = FirebaseFirestore.instance.collection("Property");
          ref
          .doc(id)
          .update({
            "description": description,
            "price": price.toString(),
            "status": selectedValue ?? widget._detail['status']
          },)
          .then((value) => Fluttertoast.showToast(msg: "Updated Successfully"))
          .catchError((e) => Fluttertoast.showToast(msg: "Failed to update : $e"));
          Navigator.of(context).pop();
          Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyProperty()));
        },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("Edit Detail"),
      // ignore: prefer_const_constructors
      content: Text("Are you sure?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  List<DropdownMenuItem<String>> get dropdownItems{
    List<DropdownMenuItem<String>> menuItems = [
      const DropdownMenuItem(value: "available", child: Text("available"), ),
      const DropdownMenuItem(value: "rented", child: Text("rented")),
      //const DropdownMenuItem(value: "Other", child: Text("Other")),
    ];

    return menuItems;
  }
  String? selectedValue;
  String? tips;

  @override
  void initState() {
    setValue();
    super.initState();
  }

  var description = "";
  var price = 0;
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  var detail = [];
  setValue(){
    setState(() {
      _descriptionController.text = widget._detail['description'];
      _priceController.text = widget._detail['price'].toString();
      tips =  widget._detail['status'];
    });
  }


  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text("Edit Property Detail"),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.all(8),
              child: Text("Address : ${widget._detail['address']}, ${widget._detail['steet']}, ${widget._detail['postal']}, ${widget._detail['city']}, ${widget._detail['state']}"),
            ),

            //price
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                
                keyboardType: TextInputType.number,
                validator: (val){
                  if(val!.isEmpty){
                    return "Enter the price";
                  }
                  else if(int.parse(val) < 1){
                    return "Price should not be 0 or smaller than 0";
                  }
                  else{
                    return null;
                  }
                },
                onChanged: (val){
                  setState(() => price = int.parse(val));
                },
                controller: _priceController,
                style: const TextStyle(
                  fontSize: 24,
                  color: Colors.blue,
                  fontWeight: FontWeight.w600,
                ),
                decoration: InputDecoration(
                  labelText: "Price",
                  focusColor: Colors.white,
                  border: const OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      width: 1.0,
                      color: Colors.blue,
                    ),
                    borderRadius: BorderRadius.circular(10)
                  ),
                  fillColor: Colors.grey,

                  hintStyle: const TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontFamily: "verdana_regular",
                  ),

                  //create label
                  labelStyle: const TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontFamily: "verdana_regular",
                  )             
                ),
              ),
            ),

            //description
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextFormField(
                controller: _descriptionController,
                onChanged: (val){
                  setState(() {
                    description = val;
                  });
                },
                style: const TextStyle(
                  fontSize: 24,
                  color: Colors.blue,
                  fontWeight: FontWeight.w600,
                ),
                decoration: InputDecoration(
                  labelText: "Description (optional)",
                  focusColor: Colors.white,
                  border: const OutlineInputBorder(),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(
                      width: 1.0,
                      color: Colors.blue,
                    ),
                    borderRadius: BorderRadius.circular(10)
                  ),
                  fillColor: Colors.grey,

                  hintStyle: const TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontFamily: "verdana_regular",
                  ),

                  //create label
                  labelStyle: const TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontFamily: "verdana_regular",
                  )             
                ),
              ),
            ),

            //status
            Container(
              padding: const EdgeInsets.all(20),
              child: DropdownButtonFormField(
                hint: Text('$tips'),
                decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.blue, width: 2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  border: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.blue, width: 2),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  filled: true,
                  fillColor: Colors.blue[100],
                ),
                //validator: (value) => value == null ? "Set status" : null,
                dropdownColor: Colors.blue[200],
                value: selectedValue,
                onChanged: (String? newValue) {
                  //print(newValue);
                  setState(() {
                    selectedValue = newValue!;
                  });
                },
                
                items: dropdownItems,
              ),
            ),

            Container(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
              margin: const EdgeInsets.all(0),
              child: ElevatedButton(
                onPressed: () async {
                  showAlertDialog(context, widget._detail['pid'].toString());
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[400],
                  minimumSize: const Size(100,50),
                  fixedSize: const Size(400, 50)
                ),
                child: Text('Update detail'.toUpperCase()),         
              ),
            )
          ],
        ) 
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}