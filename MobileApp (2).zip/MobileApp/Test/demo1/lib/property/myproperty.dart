import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';

import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/add_property.dart';
import 'package:demo1/property/addmoreimg.dart';
import 'package:demo1/property/addproperty.dart';
import 'package:demo1/property/edit_property.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class MyProperty extends StatefulWidget {
  const MyProperty({super.key});

  @override
  State<MyProperty> createState() => _MyPropertyState();
}

class _MyPropertyState extends State<MyProperty> {
  int _selectedIndex = 1;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  final _firestoreInstance = FirebaseFirestore.instance;
  List _property = [];
  fetchMyProperty() async {
    QuerySnapshot qn = await _firestoreInstance.collection('Property')
    .where("owned-by", isEqualTo: FirebaseAuth.instance.currentUser!.email)
    .where("isDeleted", isEqualTo: "no")
    .get();
    //QuerySnapshot qn = await _firestoreInstance.collection('Property').where("owned-by", isEqualTo: "").get();
    //print("Length: ${qn.docs.length}");
    setState(() {
      for(int i = 0; i<qn.docs.length; i++){
        _property.add(
          {
            "address": qn.docs[i]['address'],
            "bathroom": qn.docs[i]['bathroom'],
            "city": qn.docs[i]['city'],
            "description": qn.docs[i]['description'],
            "owned-by": qn.docs[i]['owned-by'],
            "pid": qn.docs[i]['pid'],
            "postal": qn.docs[i]['postal'],           
            "price": qn.docs[i]['price'],
            "img": qn.docs[i]['property-img'],    
            "property-name": qn.docs[i]['property-name'],
            "room": qn.docs[i]['room'],
            "state": qn.docs[i]['state'],
            "status": qn.docs[i]['status'],          
            "street": qn.docs[i]['street'],   
            "updatedOn": qn.docs[i]['updatedOn'],      
          } 
        );
      }
      // ignore: avoid_print
      //print('${_property}');
    });
  }

  
  showAlertDialog(BuildContext context, String id) {
  // set up the buttons
  // ignore: unused_local_variable
    Widget cancelButton = TextButton(
      child: const Text("No"),
      onPressed:  () {
        Navigator.of(context).pop();
      },
    );
    Widget continueButton = TextButton(
      child: const Text("Yes"),
      onPressed:  () {
          CollectionReference collectionRef = FirebaseFirestore.instance.collection('Property');
          collectionRef.doc(id).update(
            {
              "isDeleted": "yes",
            }
          ).then((value) { 
            Fluttertoast.showToast(msg: 'Successfully Deleted');
            setState(() {
              _property.clear();
              fetchMyProperty();
              showProperty();
            });
            
          });
          Navigator.of(context).pop();
        },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("Delete"),
      // ignore: prefer_const_constructors
      content: Text("Are you sure?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
  

  showProperty(){
    if(_property.isEmpty){
      return Column(
        //crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            margin: EdgeInsets.only(left: 80),
            alignment: Alignment.center,
            child:  const Center(
              child: CircleAvatar(
                radius: 100,
                backgroundColor: Colors.red,
                child: Icon(Icons.cancel, color: Colors.white,size: 200,),
              ),
            )
          ),
          Container(
            margin: EdgeInsets.only(left: 80), 
            child: const Text("Currently there are no property", style: TextStyle(fontSize: 18, ),)),
        ],
      );
    }else{
      return Expanded(
        child: ListView.builder(
          scrollDirection: Axis.vertical,
          itemCount: _property.length,

          itemBuilder: (_, index) {
            return  Container(
              padding: const EdgeInsets.all(10),
              child: Card(
                elevation: 3,
                child: Column(
                  children: <Widget>[
                    ListTile(
                      leading: ConstrainedBox(
                        constraints: const BoxConstraints(
                          minWidth: 100,
                          minHeight: 100,
                          maxHeight: 120,
                          maxWidth: 120,
                        ),child: Image.network(_property[index]["img"][0], fit: BoxFit.fill,),
                      ),
                      title: Text("${_property[index]["address"]},${_property[index]["street"]},${_property[index]["city"]}, ${_property[index]["state"]}"),
                      subtitle: Text("RM${_property[index]["price"].toString()}", style: const TextStyle(color: Colors.blue),),
                    ),       
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        TextButton(
                          child: const Text('Add More Image', style: TextStyle(color: Colors.blue),),
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder:(context)=> AddMoreImage(_property[index])));
                          },
                        ),
                        const SizedBox(width: 8),
                        TextButton(
                          child: const Text('EDIT', style: TextStyle(color: Colors.blue),),
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder:(context)=> EditProperty(_property[index])));
                          },
                        ),
                        const SizedBox(width: 8),
                        TextButton(
                          child: const Text('DELETE'),
                          onPressed: () {
                            showAlertDialog(context, _property[index]["pid"].toString());
                          },
                        ),
                        const SizedBox(width: 8),
                      ],
                    )           
                  ],
                ),
              ),
            );
          },
          ),
      );
    }
  }

  @override
  void initState() {
    //getCurrentUser();
    fetchMyProperty();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('My property'),
        // ignore: prefer_const_literals_to_create_immutables
        actions: <Widget>[
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: IconButton(
              icon: const Icon(Icons.add),
              tooltip: 'Add Property',
              onPressed: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context) => const Add_Property()));
              },
            )
          )
        ],
      ),
      body: SafeArea(
        child: Row(children: [showProperty()],)
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}