import 'package:demo1/property/addimg.dart';
import 'package:demo1/property/myproperty.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:demo1/services/image_upload.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;

class AddProperty extends StatefulWidget {
  const AddProperty({super.key});

  @override
  State<AddProperty> createState() => _AddPropertyState();
}

class _AddPropertyState extends State<AddProperty> {
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final postalController = TextEditingController();
  final cityController = TextEditingController();
  final stateController = TextEditingController();
  final houseController = TextEditingController();
  bool loading = false;
  String error = '';
  int _selectedIndex = 1;
  String houseNo = '';
  String name = '';
  String city = "";
  String state = '';
  int postal = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  // final ImagePicker _picker = ImagePicker();
  // List<XFile> images = [];
  // List<String> listImagePath = [];
  // var selectedFileCount = 0.obs;
  // void selectedMultipleImage() async{
  //   images = await _picker.pickMultiImage();
  //   if(images != null){
  //     for(XFile file in images){
  //       listImagePath.add(file.path);
  //     }
  //   }else{
  //     Get.snackbar("Fail", "No image selected", 
  //     snackPosition: SnackPosition.BOTTOM,
  //     backgroundColor: Colors.red,
  //     colorText: Colors.white
  //     );
  //   }
  //   selectedFileCount.value=listImagePath.length;
  // }

  // void uploadImage(){

  // }
  final ImageUpload storage = ImageUpload();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Property Information'),
      ),
      body: SingleChildScrollView(
        //Type your code here   
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //house number
              Container(
                padding: const EdgeInsets.all(20),
                alignment: Alignment.center,
                child: TextFormField(
                  //autofillHints: const [AutofillHints.streetAddressLevel1],
                  validator: (val) => val!.isEmpty ? "Enter House Number" : null,
                  onChanged: (val){
                    setState(() => name = val);
                  },
                  controller: houseController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "House Number",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    // prefixIcon: const Icon(
                    //   Icons.numbers,
                    //   color: Colors.grey,
                    // ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,

                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),

                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //street name
              Container(
                padding: const EdgeInsets.all(20),
                alignment: Alignment.center,
                child: TextFormField(
                  autofillHints: const [AutofillHints.streetAddressLevel1],
                  validator: (val) => val!.isEmpty ? "Enter a name" : null,
                  onChanged: (val){
                    setState(() => name = val);
                  },
                  controller: nameController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Street",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    // prefixIcon: const Icon(
                    //   Icons.streetview,
                    //   color: Colors.grey,
                    // ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,

                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),

                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //postal
              Container(
                padding: const EdgeInsets.all(20),
                alignment: Alignment.center,
                child: TextFormField(
                  autofillHints: const [AutofillHints.postalCode],
                  keyboardType: TextInputType.number,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the postal";
                    }else if (val.length != 5){
                      return "Postal must be 5 digti";
                    }else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => postal = int.parse(val));
                  },
                  controller: postalController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "Postal/Zip code",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    // prefixIcon: const Icon(
                    //   Icons.person_outline_rounded,
                    //   color: Colors.grey,
                    // ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,

                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),

                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //city
              Container(
                padding: const EdgeInsets.all(20),
                alignment: Alignment.center,
                child: TextFormField(
                  autofillHints: const [AutofillHints.addressCity],
                  keyboardType: TextInputType.streetAddress,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the city name";
                    }else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => city = val);
                  },
                  controller: cityController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "City",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    // prefixIcon: const Icon(
                    //   Icons.person_outline_rounded,
                    //   color: Colors.grey,
                    // ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,

                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),

                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //state
              Container(
                padding: const EdgeInsets.all(20),
                alignment: Alignment.center,
                child: TextFormField(
                  autofillHints: const {AutofillHints.addressState},
                  keyboardType: TextInputType.streetAddress,
                  validator: (val){
                    if(val!.isEmpty){
                      return "Enter the state name";
                    }else{
                      return null;
                    }
                  },
                  onChanged: (val){
                    setState(() => state = val);
                  },
                  controller: stateController,
                  style: const TextStyle(
                    fontSize: 24,
                    color: Colors.blue,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: "State",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    // prefixIcon: const Icon(
                    //   Icons.person_outline_rounded,
                    //   color: Colors.grey,
                    // ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: const BorderSide(
                        width: 1.0,
                        color: Colors.blue,
                      ),
                      borderRadius: BorderRadius.circular(10)
                    ),
                    fillColor: Colors.grey,

                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),

                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )             
                  ),
                ),
              ),

              //img
              

              //button
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(200,50),
                  backgroundColor: const Color.fromARGB(255, 3, 109, 248),
                  side: const BorderSide(width: 2),                    
                ),
                onPressed: () async {
                  if(_formKey.currentState!.validate()){
                    // Navigator.push(
                    //   context, 
                    //   MaterialPageRoute(builder: (context) => AddImg(det)),
                    // );
                  }
                },
                child: Text(
                  "Next".toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold
                  ),
                ),
              )
            ],
          )        
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}