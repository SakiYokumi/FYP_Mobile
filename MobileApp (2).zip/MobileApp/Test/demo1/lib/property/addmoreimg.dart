import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/property/myproperty.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';

class AddMoreImage extends StatefulWidget {
  var _detail;
  AddMoreImage(this._detail, {super.key});

  @override
  State<AddMoreImage> createState() => _AddMoreImageState();
}

class _AddMoreImageState extends State<AddMoreImage> {
  @override
  void initState() {
    // TODO: implement initState
    setValue();
    super.initState();
  }

  List<dynamic> temp = [];
  setValue(){
    setState(() {
      temp.addAll(widget._detail['img']);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        title: const Text("Add more images"),
        backgroundColor: Colors.blue[400],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: BorderSide( width: 2.5, color: Colors.blue.withOpacity(0.5),),
                    maximumSize: const Size(200, 120),
                  ),
                  onPressed: (){
                    _selectImage();
                  },
                  child: 
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 40, 14, 40), 
                    child: Column(
                      // ignore: prefer_const_literals_to_create_immutables
                      children: [
                        const Icon(
                          Icons.add, 
                        ),
                        const Text("Upload Image"),
                      ],
                    )
                  )
                ),
              ),
            ),
            displayImg(),
            Container(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                margin: const EdgeInsets.all(0),
                child: ElevatedButton(
                  onPressed: (){
                    temp.isEmpty?Fluttertoast.showToast(msg: "No image selected") :showAlertDialog(context, widget._detail['pid'].toString());
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[400],
                    minimumSize: const Size(100,50),
                    fixedSize: const Size(400, 50)
                  ),
                  child: Text('Add image'.toUpperCase()),         
                ),
              ),
          ],
        )
      ),
    );
  }
  
  displayImg() {
    return temp.isNotEmpty?
    Expanded(
      child: ListView.builder(
        itemCount: temp.length,
        itemBuilder: ((context, index) {
          return Container( 
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
            child: Row(
              children: [
                Container(
                  color: Colors.red,
                  height: 200,
                  width: 300,
                  child: FittedBox(
                    child: Image.network(temp[index], height: 200, width: 300, fit: BoxFit.fill,),
                  )
                ),           
                ElevatedButton(
                  onPressed: (){
                    setState(() {
                      temp.removeAt(index);
                    });
                  },  
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),      
                  child: Center(
                    child: Container(
                      height: 200,
                      child: const Icon(
                        Icons.cancel,color: Colors.white,
                      )
                    ),
                  ),
                )
              ],   
            )                       
          );
        })
      ),
    ):
    const Padding(
      padding: EdgeInsets.all(8.0),
        child: Text("Upload some images", textAlign: TextAlign.center,),
    );
  }
  
  void _selectImage() async {
    final tempImg = await ImagePicker().pickImage(source: ImageSource.gallery);
    if(tempImg == null){
      Fluttertoast.showToast(msg: "No image selected");
    }else{
      Reference ref = FirebaseStorage.instance.ref().child("property/${tempImg.name}");
      await ref.putFile(File(tempImg.path));
      ref.getDownloadURL().then((value) {
        temp.add(value);
        setState(() {
          displayImg();
        });
      });
    }
  }
  
  showAlertDialog(BuildContext context, String id) {
    Widget cancelButton = TextButton(
      child: const Text("No"),
      onPressed:  () {
        Navigator.of(context).pop();
      },
    );
    Widget continueButton = TextButton(
      child: const Text("Yes"),
      onPressed:  () {
          CollectionReference ref = FirebaseFirestore.instance.collection("Property");
          ref
          .doc(id)
          .update({
            "property-img": temp
          },)
          .then((value) => Fluttertoast.showToast(msg: "Updated Successfully"))
          .catchError((e) => Fluttertoast.showToast(msg: "Failed to update : $e"));
          Navigator.of(context).pop();
          Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyProperty()));
        },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("Update detail"),
      // ignore: prefer_const_constructors
      content: Text("Are you sure?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );

  }
}