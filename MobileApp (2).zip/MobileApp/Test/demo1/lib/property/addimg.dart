// ignore_for_file: unused_import
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/services/image_upload.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

class AddImg extends StatefulWidget {
  //const AddImg({super.key});
  var _detail;
  AddImg(this._detail, {super.key});
  @override
  State<AddImg> createState() => _AddImgState();
}

class _AddImgState extends State<AddImg> {
  final ImageUpload storage = ImageUpload();
  var name = '';
  int _selectedIndex = 1;
  var img = [];
  
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  showImg(){
    return FutureBuilder(
      future: storage.downloadURL(name),
      builder: (context,AsyncSnapshot<String> snapshot) {
        if(snapshot.connectionState == ConnectionState.done && snapshot.hasData){
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            height: 300,
            width: 250,
            child: Image.network(snapshot.data!, fit: BoxFit.cover)
          );
        }
        if(snapshot.connectionState == ConnectionState.waiting || !snapshot.hasData){
          return const CircularProgressIndicator();
        }
        return Container();
      },
    );
  }

  var test = [1,2,3];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Add Image'),
      ),

      body: SafeArea(
        child: Column(
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: BorderSide( width: 2.5, color: Colors.blue.withOpacity(0.5),),
                    maximumSize: const Size(200, 120),
                  ),
                  onPressed: (){
                    _selectImage();
                  },
                  child: 
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 40, 14, 40), 
                    child: Column(
                      // ignore: prefer_const_literals_to_create_immutables
                      children: [
                        const Icon(
                          Icons.add, 
                        ),
                        const Text("Upload Image"),
                      ],
                    )
                  )
                ),
              ),
            ),
            displayImg(),
            Container(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                margin: const EdgeInsets.all(0),
                child: ElevatedButton(
                  onPressed: (){

                    img.isEmpty?Fluttertoast.showToast(msg: "No image selected") :insertProperty();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[400],
                    minimumSize: const Size(100,50),
                    fixedSize: const Size(400, 50)
                  ),
                  child: Text('Add property'.toUpperCase()),         
                ),
              ),
            // Padding(
            //   padding: const EdgeInsets.all(8.0),
            //   child: OutlinedButton(
            //     style: OutlinedButton.styleFrom(
            //       minimumSize: const Size(200,50),
            //       backgroundColor: Colors.green,
            //       side: const BorderSide(width: 2),                    
            //     ),
            //     onPressed: () async {
            //       final results = await FilePicker.platform.pickFiles(
            //         allowMultiple: false,
            //         type: FileType.custom,
            //         allowedExtensions: ['png', 'jpg']
            //       );

            //       if(results == null){
            //         // ignore: use_build_context_synchronously
            //         ScaffoldMessenger.of(context).showSnackBar(
            //           const SnackBar(content: Text("No file selected."),),
            //         );
            //         return null;
            //       }

            //       final path = results.files.single.path!;
            //       final fileName = results.files.single.name;

            //       storage.uploadFile(path, fileName).then((value) => print('done'));
            //     },
            //     child: Text(
            //       "Upload File".toUpperCase(),
            //       style: const TextStyle(
            //         color: Colors.white,
            //         fontWeight: FontWeight.bold
            //       ),
            //     ),
            //   ),
            // ),

            // FutureBuilder(
            //   future: storage.listFiles(),
            //   builder: (context,AsyncSnapshot<firebase_storage.ListResult> snapshot) {
            //     if(snapshot.connectionState == ConnectionState.done && snapshot.hasData){
            //       return Container(
            //         padding: const EdgeInsets.symmetric(horizontal: 20),
            //         height: 100,
            //         child: ListView.builder(
            //           scrollDirection: Axis.horizontal,
            //           shrinkWrap: true,
            //           itemCount: snapshot.data!.items.length,
            //           itemBuilder: ((context, index) {
            //             return ElevatedButton(
            //               onPressed: (){
            //                 name = snapshot.data!.items[index].name;
            //                 showImg();
            //               }, 
            //               child: Text(snapshot.data!.items[index].name),
            //             );
            //           })
            //         ),
            //       );
            //     }
            //     if(snapshot.connectionState == ConnectionState.waiting || !snapshot.hasData){
            //       return const CircularProgressIndicator();
            //     }
            //     return Container();
            //   },
            // ),     
          ],
        ),
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );

    
  }

  _selectImage() async {
    final tempImg = await ImagePicker().pickImage(source: ImageSource.gallery);
    if(tempImg == null){
      Fluttertoast.showToast(msg: "No image selected");
    }else{
      Reference ref = FirebaseStorage.instance.ref().child("property/${tempImg.name}");
      await ref.putFile(File(tempImg.path));
      ref.getDownloadURL().then((value) {
        img.add(value);
        setState(() {
          displayImg();
        });
      });
    }
  }
  
  displayImg() {
    if(img.isNotEmpty){
      return Expanded(
        child: ListView.builder(
          itemCount: img.length,
          itemBuilder: ((context, index) {
            return Container( 
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
              child: Row(
                children: [
                  Container(
                    color: Colors.red,
                    height: 200,
                    width: 300,
                    child: FittedBox(
                      child: Image.network(img[index], height: 200, width: 300, fit: BoxFit.fill,),
                    )
                  ),           
                  ElevatedButton(
                    onPressed: (){
                      setState(() {
                        img.removeAt(index);
                      });
                    },  
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),      
                    child: Center(
                      child: Container(
                        height: 200,
                        child: const Icon(
                          Icons.cancel,color: Colors.white,
                        )
                      ),
                    ),
                  )
                ],
                
              )       
                                  
            );
          })
        ),
      );
    }else{
      return const Padding(
        padding: EdgeInsets.all(8.0),
        child: Text("Upload some images", textAlign: TextAlign.center,),
      );
    }
            
            
  }
  
  //var exp = ['1', 'asd', 'qwe'];
  void insertProperty() async{
    var db = FirebaseFirestore.instance;
    QuerySnapshot qn = await db.collection("Property").get();
    List<DocumentSnapshot> _doc = qn.docs;
    //print("${_doc.length + 1} records");
    int num = _doc.length + 1;
    CollectionReference ref = db.collection('Property');
    await ref
    .doc(num.toString())
    .set(
      {
        "address": widget._detail['address'] ?? "",
        "bathroom": widget._detail['bathroom'] ?? "",
        "city": widget._detail['city'] ?? "",
        "description": widget._detail['description'] ?? "",
        "isDeleted": "no",
        "owned-by": widget._detail['owned-by'] ?? "",
        'pid': num ,
        'postal': widget._detail['postal'] ?? "",
        'price' : widget._detail['price'] ?? "",
        'property-img': img ,
        'property-name': widget._detail['property-name'] ?? "",
        'room': widget._detail['room'] ?? "",
        'state': widget._detail['state'] ?? "",
        'status': "available",
        'street': widget._detail['street'] ?? "",
        "updatedOn": Timestamp.now(),
      }
    ).then((value) => Fluttertoast.showToast(msg: "Added Successfully")
    .catchError((error) => Fluttertoast.showToast(msg: "Oops Something is wrong")));
    Navigator.push(context, MaterialPageRoute(builder: (context) => const PropertyMain()));
  }
}