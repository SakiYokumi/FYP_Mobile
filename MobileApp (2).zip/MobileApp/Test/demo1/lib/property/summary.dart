import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/user/usermain.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:intl/intl.dart';
class Summary extends StatefulWidget {
  const Summary({super.key});

  @override
  State<Summary> createState() => _SummaryState();
}

class _SummaryState extends State<Summary> {
  String currentDate = DateFormat('yyy-MM-dd KK:mm:ss').format(DateTime.now());
  //  String currentDate = DateFormat('yyyy-MM-dd KK:mm:ss').format(DateTime.now());
  int _selectedIndex = 1;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update() {
    if (_selectedIndex == 0) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    } else if (_selectedIndex == 1) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const Summary()),
      );
    } else if (_selectedIndex == 2) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    } else if (_selectedIndex == 3) {
      _selectedIndex == 3;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  @override
  void initState() {
    // _streamSummary = _referenceSummary.snapshots();
  }

  @override
  Widget build(BuildContext context) {
    // _referenceSummary.get();
    // _referenceSummary.snapshots();
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        // automaticallyImplyLeading: false,
        backgroundColor: Colors.blue[400],
        title: const Text('My Summary'),
      ),
      body: SingleChildScrollView(
        //Type your code here
        scrollDirection: Axis.vertical,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Container(
                  margin: const EdgeInsets.fromLTRB(0, 20, 0, 00),
                  child: const Center(
                    child: CircleAvatar(
                      radius: 100,
                      backgroundColor: Colors.black,
                      child: Icon(
                        Icons.home,
                        color: Colors.white,
                        size: 100,
                      ),
                    ),
                  )),
             Container(
  child: StreamBuilder(
    stream: FirebaseFirestore.instance.collection("Payment").snapshots(),
    builder: ((context, snapshot) {
      if (snapshot.hasError) {
        return Center(child: Text("Something went wrong"));
      }
      if (snapshot.connectionState == ConnectionState.waiting) {
        return Center(child: Text("Loading"));
      }
      return SingleChildScrollView(
        child: Column(
          children: [
            ListView(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              children: snapshot.data!.docs.map((DocumentSnapshot document) {
                Map<String, dynamic> data = document.data() as Map<String, dynamic>;
                return ListTile(
                  title: Text('Payment ID: ${data['PaymentID']} \n\n Payer: ${data['payBy']} \n\n Payee: ${data['payTo']} \n\n Date Time: $currentDate \n\n Debit: ${data['debit']}'),
                );
              }).toList(),
            ),
          ],
        ),
      );
    }),
  ),
)
            ]),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home,
              color: Colors.black,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.business,
              color: Colors.black,
            ),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.chat_outlined,
              color: Colors.black,
            ),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.people,
              color: Colors.black,
            ),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}
