import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/model/account.dart';

class DatabaseService {
  final String? uid;
  DatabaseService({ required this.uid });

  //collection reference
  final CollectionReference accountCollection = FirebaseFirestore.instance.collection('UserAcc');

  Future updateUserData(String uid,String email, String username, int phone) async {
    return await accountCollection.doc(uid).set({
      'uid' : uid,
      'email' : email,
      'username' : username,
      'phoneNo' : phone,
    });
  }

  //list from snapshot
  List<Account> _accountFromSnapshot(QuerySnapshot snapshot){
    return snapshot.docs.map((doc) {
      return Account(
        email: doc.get('email') ?? '',
        password: doc.get('password') ?? 0,
      );
    }).toList();
  }

  //get
  Stream<List<Account>> get account {
    return accountCollection.snapshots().map(_accountFromSnapshot);
  }
}