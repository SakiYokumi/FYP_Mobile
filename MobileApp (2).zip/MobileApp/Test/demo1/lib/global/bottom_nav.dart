import 'package:demo1/Home/homepage.dart';

import 'package:demo1/user/usermain.dart';
import 'package:flutter/material.dart';

class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _selectedIndex = 0;
  int _page = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _page = _selectedIndex;
    });
    update();
  }

  void update(){
    if(_page == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){

    }
    else if(_selectedIndex == 2){

    }else if(_page == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.blue[600],
      unselectedItemColor: Colors.white70,
      items: const <BottomNavigationBarItem>[
        
        BottomNavigationBarItem(          
          icon: Icon(Icons.home, color: Colors.black,),
          label: 'Home', 
          
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.business, color: Colors.black,),
          label: 'Property',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.chat_outlined, color: Colors.black,),
          label: 'Chat',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.people, color: Colors.black,),
          label: 'Profile',
        ),
      ],
      currentIndex: _selectedIndex,
      selectedItemColor: Colors.amber[800],
      onTap: _onItemTapped,
    );
  }
}