// ignore_for_file: prefer_const_constructors, duplicate_ignore

import 'package:demo1/authenticate/loginpage.dart';
import 'package:demo1/authenticate/signup.dart';
import 'package:flutter/material.dart';

class Body extends StatelessWidget {
  const Body({super.key});

  @override
  Widget build(BuildContext context) {
    // ignore: duplicate_ignore
    return Column(
      crossAxisAlignment:  CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      // ignore: prefer_const_literals_to_create_immutables
      children: [
        CircleAvatar(
          minRadius: 150,
          backgroundColor: Colors.blue[400],
          child: Icon(Icons.home, size: 250,color: Colors.white,),
          
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            "Welcome",
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 50,
                fontWeight: FontWeight.bold,
                color: Color(0xff000000), 
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            "A Higher Quality of Living.",
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.grey, 
            ),
          ),
        ),
          
        SizedBox(height: 20,),
        Row(
          children: [
            Expanded(           
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[400],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(45),
                    ),
                    side: BorderSide(width: 1),
                    minimumSize: Size(100, 60)
                  ),
                  
                  onPressed: (){
                    Navigator.push(
                      context, 
                      MaterialPageRoute(builder: (context) => const LoginPage())
                    );
                  },
                  child: const Text(
                    'LOGIN',
                    style: TextStyle(
                      fontSize: 24,
                    )
                  ),              
                ),
              ),
            ),
            Expanded(           
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(45),
                    ),
                    side: BorderSide(width: 1),
                    minimumSize: Size(100, 60)
                  ),
                  onPressed: (){
                      Navigator.push(
                      context, 
                      MaterialPageRoute(builder: (context) => const SignUp())
                    );
                  },
                  child: const Text(
                    'REGISTER',
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.black
                    ),
                  ),              
                ),
              ),
            )
          ],
        ),
        
      ],
    );
  }
}