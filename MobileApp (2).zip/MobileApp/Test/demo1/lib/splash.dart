import 'dart:async';

import 'package:demo1/welcome.dart';
import 'package:flutter/cupertino.dart';
import 'package:just_audio/just_audio.dart';
import 'package:flutter/material.dart';

class Splah extends StatefulWidget {
  const Splah({super.key});

  @override
  State<Splah> createState() => _SplahState();
}

AudioPlayer player = AudioPlayer();
class _SplahState extends State<Splah> {
  @override
  void initState() {
    Timer(const Duration(seconds: 3), ()=>Navigator.push(context, CupertinoPageRoute(builder: (_)=>const Welcome())));
    super.initState();
    player.setAsset('assets/fun.mp3');
    player.setVolume(1.0);
    playSound();
  }



  //Map<int, Widget> output = {1: Welcome()};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.only(left: 50),
            child: Image.asset(
              "assets/images/HRMsLogo.jpg",
              fit: BoxFit.cover,
              alignment: Alignment.center,
            ),
          )
        ],
      )
    );
  }
  
  void playSound() async {
    player.play();
  }
}
