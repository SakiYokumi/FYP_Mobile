// ignore_for_file: file_names, prefer_typing_uninitialized_variables, prefer_final_fields


import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/Home/viewcomment.dart';
// import 'package:demo1/Payment/payment.dart';
// import 'package:demo1/chat/chatmain.dart';
// import 'package:demo1/chat/chatowner.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:fluttertoast/fluttertoast.dart';

// ignore: must_be_immutable
class PropertyDetail2 extends StatefulWidget {
  //const PropertyDetail({super.key});
  var _property;
  
  PropertyDetail2(this._property, {super.key});
  @override
  State<PropertyDetail2> createState() => _PropertyDetail2State();
}


class _PropertyDetail2State extends State<PropertyDetail2> {
  // ignore: unused_field
  final _firestoreInstance = FirebaseFirestore.instance;
  var _dotposition = 0;
  var objectLength = [];
  // fetchOwnerData() async{
  //   String email = widget._property['email'];
  //   var qn = await _firestoreInstance.collection('UserAcc').doc(email)
  //   .get().then(
  //     (DocumentSnapshot doc) {
  //       final data = doc.data() as Map<String, dynamic>;
  //       //print(data);
  //     },
  //     onError: (e) => Fluttertoast.showToast(msg: "Error getting document: $e")
  //   );
    
  // }
  
  @override
  void initState() {
    //fetchOwnerData();
    objectLength = widget._property['img'];
    super.initState();
  }

    int _selectedIndex = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      // Navigator.push(
      //   context, 
      //   MaterialPageRoute(builder: (context) => const Chat()),
      // );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        title: const Text("Property Detail"),
        backgroundColor: Colors.blue[400],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // AspectRatio(
              //   aspectRatio: 3.5,
              //   child: 
                CarouselSlider(items: widget._property["img"]
                .map<Widget>((item) => Padding(
                  padding: const EdgeInsets.only(left: 3, right: 3),
                  child: Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(image: NetworkImage(item), fit: BoxFit.fitWidth)
                    ),
                  ),
                )).toList(), options: CarouselOptions(
                  autoPlay: true,
                  enlargeCenterPage: true,
                  viewportFraction: 0.8,
                  aspectRatio: 2,
                  enlargeStrategy: CenterPageEnlargeStrategy.height,
                  onPageChanged: (val, carouselPageChangedReason){
                    setState(() {
                      objectLength.length > 1? _dotposition = val: null;
                    });
                  }
                ),),
              //),
              const SizedBox(height: 10,),
              Center(
                child:  objectLength.length > 1? DotsIndicator(
                // ignore: prefer_is_empty
                  dotsCount: objectLength.length==0?1:objectLength.length,
                  position: _dotposition.toDouble(),
                  decorator:  DotsDecorator(
                    activeColor: const Color.fromARGB(255, 255, 185, 80),
                    color: const Color.fromARGB(163, 252, 151, 0).withOpacity(0.5),
                    spacing: const EdgeInsets.all(2),
                    activeSize: const Size(8,8),
                    size: const Size(6,6),
                  ),
                ):null,
              ),
              Text("\nOwned by : ${widget._property['owned-by']}"),
              RichText(
                text: TextSpan(
                  children: [
                    const WidgetSpan(child: Icon(Icons.bed, size: 18, color: Colors.red,)),
                    TextSpan(
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 18
                      ),
                      text: "\tRoom : ${widget._property['room']}\n",
                    )
                  ]
                ),
              ),
              RichText(
                text: TextSpan(
                  children: [
                    const WidgetSpan(child: Icon(Icons.wash, size: 18, color: Colors.red,)),
                    TextSpan(
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 18
                      ),
                      text: "\tBathroom : ${widget._property['bathroom']}",
                    )
                  ]
                ),
              ),
              Text("\nRM${widget._property['price'].toString()}", style: const TextStyle(fontSize: 24, color: Colors.red),),
              const Text("\nLocated At: " , style: TextStyle(fontSize: 18),),
              Text("${widget._property["address"]},${widget._property["street"]}," , style: const TextStyle(fontSize: 18),),
              Text("${widget._property["city"]}, ${widget._property["state"]}" , style: const TextStyle(fontSize: 18),),
              Text("\nStatus : ${widget._property['status']}", style: const TextStyle(fontSize: 18)),
              Text("\nDescription : ${widget._property['description']}", style: const TextStyle(fontSize: 18)),
              Container(
                padding: const EdgeInsets.all(10),
                alignment: Alignment.bottomCenter,
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.wallet, color: Colors.white),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(200,50),
                    backgroundColor: const Color.fromARGB(255, 3, 109, 248),
                    side: const BorderSide(width: 2),         
                    
                  ),
                  onPressed: () async {
                    var owner = widget._property['owned-by'];
                    //Navigator.push(context, MaterialPageRoute(builder: (context)=>Payment(widget._property)));
                    //direct to payment
                  },
                  label: Text(
                    "Confirm Rent".toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),

              Container(
                padding: const EdgeInsets.all(10),
                alignment: Alignment.bottomCenter,
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.chat_bubble, color: Colors.white,),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(200,50),
                    backgroundColor: Colors.green,
                    side: const BorderSide(width: 2),         
                  
                  ),
                  onPressed: () async {
                    var owner = widget._property['username'];
                    //Navigator.push(context, MaterialPageRoute(builder: (context)=>ChatOwner(owner)));
                    //direct to chat
                  },
                  label: Text(
                    "Chat With Owner".toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                ),
              ),

              Container(
                padding: const EdgeInsets.all(10),
                alignment: Alignment.bottomCenter,
                child: OutlinedButton.icon(
                  // ignore: prefer_const_constructors
                  icon: Icon(Icons.comment, color: Colors.white,),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(200,50),
                    backgroundColor: const Color.fromARGB(255, 149, 135, 8),
                    side: const BorderSide(width: 2),         
                    
                  ),
                  onPressed: () {
                    var id = widget._property['pid'];
                    var owner = widget._property['owned-by'];
                    
                    var auth = FirebaseAuth.instance.currentUser;
                    var email = auth!.email;

                    //email == owner? 
                    Navigator.push(context, MaterialPageRoute(builder: (conte)=> ViewComment(id, owner)));
                    //Navigator.push(context, MaterialPageRoute(builder: (conte)=> AddComment(id, owner)));
                  },
                  label: Text(
                    "View Comment".toUpperCase(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
      
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}