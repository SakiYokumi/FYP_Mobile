import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

class ViewComment extends StatefulWidget {
  ViewComment(this._id, this.owner,{super.key});
  var _id;
  var owner;
  @override
  State<ViewComment> createState() => _ViewCommentState();
}

class _ViewCommentState extends State<ViewComment> {
  bool owner = false;
  bool _showbtn = false;
  String currentUser = "";
  String pid = "";
  var _comment = [];
  int _selectedIndex = 1;

  String temp = "";
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  getCurrentUser(){
    var auth = FirebaseAuth.instance.currentUser;
    var email = auth!.email;
    if(email == widget.owner){
      setState(() {
        owner = true;
        currentUser = email!;
      });
    }else{
      currentUser = email!;
    }
  }

  showAlertDialog(BuildContext context, String id, int index) {
  // set up the buttons
  // ignore: unused_local_variable
    Widget cancelButton = TextButton(
      child: const Text("No"),
      onPressed:  () {
        Navigator.of(context).pop();
      },
    );
    Widget continueButton = TextButton(
      child: const Text("Yes"),
      onPressed:  () {
          CollectionReference ref = FirebaseFirestore.instance.collection("comment");
          ref
          .doc(id)
          .update({
            "isDeleted": "yes"
          },)
          .then((value) {
            Fluttertoast.showToast(msg: "Deleted Comment" );
            setState(() {
              //fetchComment();
              _comment.removeAt(index);
              showComment();
            });
          })
          // ignore: invalid_return_type_for_catch_error
          .catchError((e) => Fluttertoast.showToast(msg: "Failed to delete : $e"));
          
          
          Navigator.of(context).pop();
          //Navigator.push(context, MaterialPageRoute(builder: (context)=> ViewComment(widget._id, widget.owner)));
        },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("Delete comment"),
      // ignore: prefer_const_constructors
      content: Text("Are you sure?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  fetchComment() async {
    QuerySnapshot qn = await FirebaseFirestore.instance.collection("comment")
    .where("isDeleted", isEqualTo: "no")
    .where("pid", isEqualTo: pid)
    .get();
    setState(() {
      for(int i = 0; i <qn.docs.length; i++){
        //print(qn.docs[i]['postedOn']);
        DateTime dt = (qn.docs[i]["postedOn"] as Timestamp).toDate();
        var time = DateFormat('dd/MM/yyyy').format(dt);
        _comment.add({
          "cid": qn.docs[i]['cid'],
          "description": qn.docs[i]['description'],
          "email": qn.docs[i]['email'],
          "pid": qn.docs[i]['pid'],
          "postedOn": time,//qn.docs[i]['postedOn'],
          "profile-img": qn.docs[i]['profile-img'],
          "username": qn.docs[i]['username']
        });
      }
    });
  }

  

  @override
  void initState() {
    // TODO: implement initState
    setState(() {
      pid = widget._id.toString();
    });
    initializeDateFormatting();
    getCurrentUser();
    fetchComment();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        title: const Text('Comment'),
        backgroundColor: Colors.blue[400],
        actions: [
          owner ? IconButton(
            onPressed: (){
              _showbtn =!_showbtn;
              //print(_showbtn);
              _comment.clear();
              fetchComment();
              showComment();
            }, 
            tooltip: "Delete comment",
            icon: const Icon(Icons.delete),
          ):
          IconButton(
            onPressed: (){
              //Navigator.push(context, MaterialPageRoute(builder: (context)=> AddComment()));
              _displayTextInputDialog(context);
            }, 
            tooltip: "Add comment",
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: SafeArea(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _comment.isEmpty ?
            const Center(
              child: Text(
                'Currently there are no comment'
                ),
              ) 
            :showComment(),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
  
  showComment() {
    return Expanded(
      child: ListView.builder(
        itemCount: _comment.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(8),
            child: Card(
              elevation: 3,
              child: Column(
                children: [
                  ListTile(
                    leading: _comment[index]['profile-img'] != ""?CircleAvatar(
                      backgroundImage: NetworkImage(_comment[index]['profile-img'])
                    ):CircleAvatar(child: Icon(Icons.person),),
                    title: RichText(
                      text: TextSpan(
                        text: "${_comment[index]['username']}",
                        style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                        children: [
                          TextSpan(text: "\tPosted On ${_comment[index]['postedOn']}", style: const TextStyle(color: Colors.grey)),
                        ]
                      ),
                    ),
                    subtitle: Text("${_comment[index]['description']}"),
                    isThreeLine: true,
                    trailing: 
                    _showbtn ? IconButton(
                      icon: const Icon(Icons.delete), 
                      color: Colors.red,
                      onPressed: () async {
                        showAlertDialog(context, _comment[index]["cid"].toString(), index);
                      },
                    ):null,            
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
    
  }
  
  final _textController = TextEditingController();
  Future<void> _displayTextInputDialog(BuildContext context) async {
    final _formKey = GlobalKey<FormState>();
    
    return showDialog(
      context: context, 
      builder: (context){
        return AlertDialog(
          title: const Text('Add comment'),
          content: Form(
            key: _formKey,
            child: TextFormField(      
              maxLines: 2,
              controller: _textController,
              validator: (val) => val!.isEmpty ? "Enter your comment" : null,
              decoration: InputDecoration(
                labelText: "Comment",
                focusColor: Colors.white,
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(
                  Icons.comment,
                  color: Colors.grey,
                ),
                //errorText: 'Invalid Email',
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                    width: 1.0,
                    color: Colors.blue,
                  ),
                  borderRadius: BorderRadius.circular(10)
                ),
                fillColor: Colors.grey,

                hintStyle: const TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  fontFamily: "verdana_regular",
                ),

                //create label
                labelStyle: const TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  fontFamily: "verdana_regular",
                )             
              ),
            ),
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),    
              child: const Text('CANCEL', style: TextStyle(color: Colors.white),),
              onPressed: () {
                setState(() {
                  Navigator.pop(context);
                });
              },
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),      
              child: const Text('OK', style: TextStyle(color: Colors.white),),
              onPressed: () {
                setState(() {
                  if(_formKey.currentState!.validate()){
                    insertComment();
                    Navigator.pop(context);
                  }          
                });
              },
            ),
          ],
        );
      }
    );
  }
  
  List _userAcc = [];
  void insertComment() async{
    final FirebaseAuth auth = FirebaseAuth.instance;
    var currentUser = auth.currentUser;
    var db = FirebaseFirestore.instance;
    QuerySnapshot qn = await db.collection("comment").get();
    List<DocumentSnapshot> _doc = qn.docs;
    int num = _doc.length + 1;

    QuerySnapshot ref = await db.collection('UserAcc')
    .where("email", isEqualTo: currentUser!.email)
    .get();
    setState(() {
      _userAcc.add({
        "email": ref.docs[0]['email'],
        "profile-img": ref.docs[0]['profile-img'],
        'username': ref.docs[0]['username']
      });
    });
    
    CollectionReference ref2 = await db.collection("comment");
    await ref2.doc(num.toString()).set({
      "cid": num.toString(),
      "description": _textController.text,
      "email": currentUser.email,
      "isDeleted": "no",
      "pid": widget._id,
      "postedOn": Timestamp.now(),
      "profile-img": _userAcc[0]['profile-img'],
      "username": _userAcc[0]['username']
    }).then((value) => {
      Fluttertoast.showToast(msg: "Successfully added"),
      _comment.clear(),
      fetchComment(),
      showComment(),
      _textController.text = "",
    })
    .catchError((onError)=> Fluttertoast.showToast(msg: "Something went wrong"));
  }  
}