// ignore_for_file: prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/propertydetail.dart';
import 'package:demo1/Home/propertydetail2.dart';
import 'package:flutter/material.dart';

class Search extends StatefulWidget {
  const Search({super.key});

  @override
  State<Search> createState() => _SearchState();
}

class _SearchState extends State<Search> {
  var inputText = "";
  List detail = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('search'),),
      body: SafeArea(
        child: Column(
          children: [
            TextFormField(
              onChanged: (value) {
                setState(() {
                  inputText = value;
                });
              },
              decoration: const InputDecoration(
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(0)),
                  borderSide: BorderSide(
                    color: Colors.blue
                  )
                ),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(0)),
                    borderSide: BorderSide(
                        color: Colors.grey
                    )
                ),
                hintText: "Enter street name",
                hintStyle: TextStyle(fontSize: 15.0),
              ),
            ),
            Expanded(
              // ignore: avoid_unnecessary_containers
              child: Container(
                child: StreamBuilder(
                  stream: FirebaseFirestore.instance.
                  collection("Property")
                  .where("street", isEqualTo: inputText)
                  .where("isDeleted", isEqualTo: 'no')
                  .snapshots(),
                  builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot){
                    if(snapshot.hasError){
                      return Center(child:Text("Something went wrong"),);
                    }
                    if(snapshot.connectionState==ConnectionState.waiting){
                      return Center(child: Text("Loading"),);
                    }
                    return ListView(
                      children: 
                        snapshot.data!.docs.map((DocumentSnapshot document){
                          Map<String, dynamic> data = document.data() as Map<String, dynamic>;
                          return GestureDetector(
                            onTap: (){ 
                              setState(() {
                                detail.add({
                                  "address": data["address"],
                                  "bathroom": data['bathroom'],
                                  "city": data['city'],
                                  "description": data['description'] ?? "",
                                  "owned-by": data['owned-by'],
                                  "pid": data['pid'],
                                  "postal": data['postal'],           
                                  "price": data['price'],
                                  "img": data['property-img'],    
                                  "property-name": data['property-name'],
                                  "room": data['room'],
                                  "state": data['state'],
                                  "status": data['status'],          
                                  "street": data['street'],   
                                  "updatedOn": data['updatedOn'],  
                                });
                              });                      
                              Navigator.push(context, MaterialPageRoute(builder: (context)=>PropertyDetail(detail[0])));
                            },
                            child: Card(
                              elevation: 5,
                              child: ListTile(
                                title: Text("${data["address"]},${data["street"]},${data["city"]},${data["state"]}"),
                                leading: Image.network(data['property-img'][0]),
                              ),
                            ),
                          );
                        }).toList(),
                      
                    );
                  },
                ),
              )
            )
          ],
        ) 
      ),
    );
  }
}