// ignore_for_file: file_names, prefer_typing_uninitialized_variables, prefer_final_fields, use_build_context_synchronously


import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/addcomment.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/Home/report.dart';
import 'package:demo1/Home/viewcomment.dart';
import 'package:demo1/Payment/payment.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/chat/chatdetail.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
// ignore: unused_import
import 'package:fluttertoast/fluttertoast.dart';

// ignore: must_be_immutable
class PropertyDetail extends StatefulWidget {
  //const PropertyDetail({super.key});
  var _property;
  PropertyDetail(this._property, {super.key});
  @override
  State<PropertyDetail> createState() => _PropertyDetailState();
}


class _PropertyDetailState extends State<PropertyDetail> {
  // ignore: unused_field
  final _firestoreInstance = FirebaseFirestore.instance;
  var _dotposition = 0;
  var objectLength = [];
  @override
  void initState() {
    //fetchOwnerData();
    fetchOwner();
    objectLength = widget._property['img'];
    super.initState();
  }

    int _selectedIndex = 0;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        title: const Text("Property Detail"),
        backgroundColor: Colors.blue[400],
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => Report(widget._property)));
            },
            child: Text('Report'),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // AspectRatio(
            //   aspectRatio: 3.5,
            //   child: 
            Padding(
              padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
              child: CarouselSlider(
                items: widget._property["img"]
                .map<Widget>((item) => Padding(
                  padding: const EdgeInsets.only(left: 3, right: 3),
                  child: Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(image: NetworkImage(item), fit: BoxFit.fitWidth)
                    ),
                  ),
                )).toList(), options: CarouselOptions(
                  autoPlay: true,
                  enlargeCenterPage: true,
                  viewportFraction: 0.8,
                  aspectRatio: 2,
                  enlargeStrategy: CenterPageEnlargeStrategy.height,
                  onPageChanged: (val, carouselPageChangedReason){
                    setState(() {
                      objectLength.length > 1? _dotposition = val: null;
                    });
                  }
                ),
              ),
            ),
            //),
            const SizedBox(height: 10,),
            
            Center(
              child:  objectLength.length > 1? DotsIndicator(
              // ignore: prefer_is_empty
                dotsCount: objectLength.length==0?1:objectLength.length,
                position: _dotposition.toDouble(),
                decorator:  DotsDecorator(
                  activeColor: const Color.fromARGB(255, 255, 185, 80),
                  color: const Color.fromARGB(163, 252, 151, 0).withOpacity(0.5),
                  spacing: const EdgeInsets.all(2),
                  activeSize: const Size(8,8),
                  size: const Size(6,6),
                ),
              ):null,
            ),
            const SizedBox(height: 8,),
            Padding(padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
            child: Text(
                "Rent RM${widget._property['price'].toString()}", 
                style: const TextStyle(
                  fontSize: 24, color: Colors.red
                ), 
                textAlign: TextAlign.center,
              ),
            ),
            if (widget._property['property-name'] != "") Padding(
              padding: const EdgeInsets.fromLTRB(8.0, 0, 8, 0),
              child: Text(
                "${widget._property["property-name"]}" ,
                style: const TextStyle(color: Colors.grey),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
              child: Text(
                "${widget._property["address"]},${widget._property["street"]}, ${widget._property["city"]}, ${widget._property["state"]}" , 
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 10,),
            const Padding(
              padding: EdgeInsets.fromLTRB( 8, 0, 8, 0),
              child: Text("Property Details", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),),
            ),
            const Divider(color: Colors.black, thickness: 1.0,),

            Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
              child: displayName(),
            ),



            Padding(
              padding: const EdgeInsets.fromLTRB(8,8,8,8),
              child: Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 25,
                      //alignment: Alignment.bottomCenter,
                      //color: Colors.red,
                      child: RichText(
                        text: TextSpan(
                          children: [
                            const WidgetSpan(child: Icon(Icons.bed, size: 18, color: Colors.red,)),
                            TextSpan(
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 18
                              ),
                              text: "\tRoom : ${widget._property['room']}\n",
                            )
                          ]
                        ),
                      ),
                    ),
                  ),

                  Expanded(
                    child: SizedBox(
                      height: 25,
                      //color: Colors.blue,
                      child: RichText(
                        text: TextSpan(
                          children: [
                            const WidgetSpan(child: Icon(Icons.wash, size: 18, color: Colors.red,)),
                            TextSpan(
                              style: const TextStyle(
                                color: Colors.black,
                                fontSize: 18
                              ),
                              text: "\tBathroom : ${widget._property['bathroom']}",
                            )
                          ]
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
              child: Text("\nStatus : ${widget._property['status']}", style: const TextStyle(fontSize: 18)),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 100),
              child: Text("\nDescription : ${widget._property['description']}", style: const TextStyle(fontSize: 18)),
            ),

            Row(
              children: [
                Expanded(    
                  child: Padding(
                    padding: const EdgeInsets.only(left: 2.0, ),
                    child: ElevatedButton.icon(
                      // ignore: prefer_const_constructors
                      icon: Icon(Icons.comment, color: Colors.white,),
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(100,100),
                        backgroundColor: const Color.fromARGB(255, 149, 135, 8),               
                      ),
                      onPressed: () {
                        var id = widget._property['pid'];
                        var owner = widget._property['owned-by'];                   
                        var auth = FirebaseAuth.instance.currentUser;
                        var email = auth!.email;
                        Navigator.push(context, MaterialPageRoute(builder: (conte)=> ViewComment(id, owner)));                         
                      },
                      label: Text(
                        "View Comment".toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold
                        ),
                      ),
                    ),
                  ),
                ),

                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 2.0,),
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.wallet, color: Colors.white),
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(200,100),
                        backgroundColor: const Color.fromARGB(255, 3, 109, 248),                  
                      ),
                      onPressed: () async {
                        var owner = widget._property['owned-by'];
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>Payment(widget._property)));
                        //direct to payment
                      },
                      label: Text(
                        "Confirm Rent".toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),   
          ],
        ),
      ),
      
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
  var sender = [];
  var receiver = []; 
  var Fname = '';
  var _chat = [];
  displayName() {
    return RichText(
      text: TextSpan(
        children: [
          const TextSpan(
            text: "Owned-By : ",
            style: TextStyle(fontSize: 16, color: Colors.black),
          ),
          TextSpan(
            text: Fname,
            style: const TextStyle(
              color: Colors.blue,
              decoration: TextDecoration.underline,
            ),
            recognizer: TapGestureRecognizer()..onTap=() async{
              //print("go to chat");
              _chat.clear();
              var currentUser = FirebaseAuth.instance.currentUser;
              QuerySnapshot qn = await FirebaseFirestore.instance.collection("Chat")
              .where("FromUser", isEqualTo: currentUser!.email)
              .get();
              if(qn.docs.length == 1){
                setState(() {    
                  _chat.add({
                    "ChatID" : qn.docs[0]['ChatID'],
                    "name" : qn.docs[0]['OwnerUserName']
                  });
                });
              }

              QuerySnapshot qn2 = await FirebaseFirestore.instance.collection("Chat")
              .where("ToUser", isEqualTo: currentUser.email)
              .get();
              if(qn2.docs.length == 1){
                setState(() {    
                  _chat.add({
                    "ChatID" : qn2.docs[0]['ChatID'],
                    "name" : qn2.docs[0]['ChatUserName']
                  });
                });
              }
              
              if(_chat.isNotEmpty){
                Navigator.push(context, MaterialPageRoute(builder: (context)=> ChatDetail(_chat[0])));
              }else{  
                //get current user info    
                QuerySnapshot qn3 = await FirebaseFirestore.instance.collection("UserAcc")
                .where("email", isEqualTo: currentUser.email).get();
                setState(() {
                  sender.add({
                    "username" : qn3.docs[0]['username'],
                    "profile" : qn3.docs[0]['profile-img']
                  });
                });
                
                //get owner info
                QuerySnapshot qn4 = await FirebaseFirestore.instance.collection("UserAcc")
                .where("email", isEqualTo: widget._property['owned-by']).get();
                setState(() {
                  receiver.add({
                    "username" : qn4.docs[0]['username'],
                    "profile" : qn4.docs[0]['profile-img']
                  });
                });

                var temp = [];
                QuerySnapshot getLength = await FirebaseFirestore.instance.collection('Chat').get();
                var num = getLength.docs.length + 1;
                CollectionReference ref = FirebaseFirestore.instance.collection("Chat");
                await ref.doc(num.toString()).set({
                  "ChatID": num.toString(),
                  "ChatUserName": sender[0]['username'],
                  "FromUser": currentUser.email,
                  "OwnerUserName": Fname,
                  "ToOwner": widget._property['owned-by'],
                  "lastChat": Timestamp.now(),
                  "receiverImg": receiver[0]['profile'],
                  "senderImg": sender[0]['profile'],
                })
                .catchError((onError)=> Fluttertoast.showToast(msg: "Something went wrong"));
                setState(() {          
                  temp.add({"ChatID": num.toString(), "name": Fname});
                });
                Navigator.push(context, MaterialPageRoute(builder: (context)=> ChatDetail(temp[0])));
              }
              
            }
          ),
          const TextSpan(
            text: " << Click and Chat With Owner",
            style:  TextStyle(fontSize: 16, color: Colors.black),
          )
        ]
      )
    );
  }
  
  void fetchOwner() async {
    QuerySnapshot qn = await FirebaseFirestore.instance.collection("UserAcc")
    .where("email", isEqualTo: widget._property['owned-by'])
    .get();
    setState(() {
      Fname = qn.docs[0]['username'];
    });
  }
  

  void getUser() async{
    var currentUser = FirebaseAuth.instance.currentUser;
    QuerySnapshot qn = await FirebaseFirestore.instance.collection("UserAcc")
    .where("email", isEqualTo: currentUser!.email).get();
    setState(() {
      sender.add({
        "username" : qn.docs[0]['username'],
        "profile" : qn.docs[0]['profile-img']
      });
    });
    
    QuerySnapshot qn2 = await FirebaseFirestore.instance.collection("UserAcc")
    .where("email", isEqualTo: currentUser.email).get();
    setState(() {
      receiver.add({
        "username" : qn2.docs[0]['username'],
        "profile" : qn2.docs[0]['profile-img']
      });
    });
  }
}
