import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Report extends StatefulWidget {
  Report(this._property , {super.key});
  var _property;
  @override
  State<Report> createState() => _ReportState();
}

class _ReportState extends State<Report> {
  final List option =[
    'Fake information',
    'Price is not suitable',
    'Image contain sensitive content',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Report property'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: Column(
              children: [
                 const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    "What is wrong with this property",
                    style: TextStyle(
                      fontSize: 24,
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    width: double.infinity,
                    child: ListView.separated(
                      shrinkWrap: true,
                      itemCount: option.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () async {
                            QuerySnapshot qn =
                                await FirebaseFirestore.instance.collection("complaint").get();
                            List<DocumentSnapshot> _doc = qn.docs;
                            int num = _doc.length + 1;
                            CollectionReference ref =
                                FirebaseFirestore.instance.collection("complaint");
                            await ref.doc(num.toString()).set({
                              "id": num,
                              "content": option[index],
                              "pid": widget._property['pid'],
                              "reportAt": Timestamp.now(),
                              "isRead": "no",
                              "isDeleted": "no"
                            }).then((value){
                              Fluttertoast.showToast(msg: "Thank you for the feedback");
                              Navigator.pop(context);
                            // ignore: invalid_return_type_for_catch_error
                            }).catchError((onError) => Fluttertoast.showToast(msg: "Oops! Something went wrong."));
                          },
                          child: Container(
                            color: Colors.grey[200],
                            width: double.infinity,
                            height: 50,
                            child: Center(child: Text("${option[index]}")),
                          ),
                        );                   
                      },
                      separatorBuilder: (context, index) => const Divider(thickness: 3,),
                    ),
                  ),
                ),         
              ],
            ),
          ),
        ),
      )
    );
  }
}