import 'package:flutter/material.dart';

class AddComment extends StatefulWidget {
  AddComment(this.id, this.owner, {super.key});
  var id, owner;
  @override
  State<AddComment> createState() => _AddCommentState();
}

class _AddCommentState extends State<AddComment> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}