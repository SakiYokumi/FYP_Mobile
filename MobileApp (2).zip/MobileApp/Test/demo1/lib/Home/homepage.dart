// ignore_for_file: prefer_final_fields

import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/propertydetail.dart';
import 'package:demo1/Home/search.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/usermain.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update() {
    if (_selectedIndex == 0) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    } else if (_selectedIndex == 1) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    } else if (_selectedIndex == 2) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    } else if (_selectedIndex == 3) {
      //_selectedIndex == 3;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  int i = 0;
  final _firestoreInstance = FirebaseFirestore.instance;
  List<String> _carouselImages = [];
  List<int> _index = [];
  var _dotposition = 0;
  fetchCarouselImages() async {
    QuerySnapshot qn = await _firestoreInstance
        .collection('carousal-slider')
        .where("isDeleted", isEqualTo: 'no')
        .get();
    setState(() {
      for (int i = 0; i < qn.docs.length; i++) {
        _carouselImages.add(
          qn.docs[i]['img-path'],
        );
      }
    });

    return qn.docs;
  }

  List _property = [];
  fetchproperty() async {
    QuerySnapshot qn = await _firestoreInstance
        .collection('Property')
        .where("status", isEqualTo: "available")
        .where('isDeleted', isEqualTo: 'no')
        .get();
    setState(() {
      for (int i = 0; i < qn.docs.length; i++) {
        _property.add({
          "address": qn.docs[i]['address'],
          "bathroom": qn.docs[i]['bathroom'],
          "city": qn.docs[i]['city'],
          "description": qn.docs[i]['description'] ?? "",
          "owned-by": qn.docs[i]['owned-by'],
          "pid": qn.docs[i]['pid'],
          "postal": qn.docs[i]['postal'],
          "price": qn.docs[i]['price'],
          "img": qn.docs[i]['property-img'],
          "property-name": qn.docs[i]['property-name'],
          "room": qn.docs[i]['room'],
          "state": qn.docs[i]['state'],
          "status": qn.docs[i]['status'],
          "street": qn.docs[i]['street'],
          "updatedOn": qn.docs[i]['updatedOn'],
        });
      }
    });

    //return qn.docs;
  }

  @override
  void initState() {
    fetchCarouselImages();
    fetchproperty();
    //print(_property.length);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //Type your code here
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Homepage'),
        automaticallyImplyLeading: false,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: Column(
              children: [
                Padding(
                  // ignore: prefer_const_constructors
                  padding: EdgeInsets.all(20),
                  child: TextFormField(
                    readOnly: true,
                    onTap: () => Navigator.push(context,
                        CupertinoPageRoute(builder: (_) => const Search())),
                    decoration: const InputDecoration(
                      fillColor: Colors.white,
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(0)),
                          borderSide: BorderSide(color: Colors.blue)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(0)),
                          borderSide: BorderSide(color: Colors.grey)),
                      hintText: "Search property here",
                      hintStyle: TextStyle(fontSize: 15.0),
                    ),
                  ),
                ),
                // AspectRatio(
                //   aspectRatio: 3.5,
                //   child:
                CarouselSlider(
                  items: _carouselImages
                      .map((item) => Padding(
                            padding: const EdgeInsets.only(left: 3, right: 3),
                            child: GestureDetector(
                              child: Container(
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                  image: NetworkImage(item),
                                  fit: BoxFit.fitWidth,
                                )),
                              ),
                              onTap: () async {
                                var temp = [];
                                QuerySnapshot qn = await _firestoreInstance
                                    .collection('carousal-slider')
                                    .where("img-path", isEqualTo: item)
                                    .get();
                                setState(() {
                                  if (qn.docs.isNotEmpty) {
                                    if (qn.docs[0]['pid'] != "") {
                                      temp.add({
                                        'pid': qn.docs[0]['pid'],
                                      });
                                    }
                                    else{
                                      temp.clear();
                                    }
                                  } else {
                                    temp.clear();
                                  }
                                });
                                temp.isNotEmpty && temp[0]['pid'] != null
                                    ? goToPageDetail(temp[0]['pid'])
                                    :Fluttertoast.showToast(msg: "Item Not Found!");
                              },
                            ),
                          ))
                      .toList(),
                  options: CarouselOptions(
                      autoPlay: true,
                      enlargeCenterPage: true,
                      aspectRatio: 2.0,
                      viewportFraction: 0.8,
                      enlargeStrategy: CenterPageEnlargeStrategy.height,
                      onPageChanged: (val, carouselPageChangedReason) {
                        setState(() {
                          _dotposition = val;
                        });
                      }),
                ),
                //),
                const SizedBox(
                  height: 10,
                ),
                DotsIndicator(
                  // ignore: prefer_is_empty
                  dotsCount:
                      _carouselImages.isEmpty ? 1 : _carouselImages.length,
                  position: _dotposition.toDouble(),
                  decorator: DotsDecorator(
                    activeColor: const Color.fromARGB(255, 255, 185, 80),
                    color:
                        const Color.fromARGB(163, 252, 151, 0).withOpacity(0.5),
                    spacing: const EdgeInsets.all(2),
                    activeSize: const Size(8, 8),
                    size: const Size(6, 6),
                  ),
                ),
                // ignore: prefer_const_constructors
                SizedBox(
                  height: 10.0,
                ),
                Expanded(
                    child: GridView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  scrollDirection: Axis.vertical,
                  itemCount: _property.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 1,
                  ),
                  itemBuilder: (_, index) {
                    return GestureDetector(
                      child: Card(
                        elevation: 3,
                        child: Column(
                          children: [
                            AspectRatio(
                                aspectRatio: 2,
                                child: Container(
                                    color: Colors.yellow,
                                    child: Image.network(
                                      _property[index]["img"][0],
                                      fit: BoxFit.fill,
                                    ))),
                            Text(
                                "${_property[index]["address"]},${_property[index]["street"]},"),
                            Text(
                                "${_property[index]["city"]}, ${_property[index]["state"]}"),
                            Text(
                              "RM${_property[index]["price"].toString()}",
                              style: const TextStyle(color: Colors.blue),
                            ),
                          ],
                        ),
                      ),
                      onTap: () {
                        //print(_property[index]);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    PropertyDetail(_property[index])));
                      },
                    );
                  },
                )),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home,
              color: Colors.black,
            ),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.business,
              color: Colors.black,
            ),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.chat_outlined,
              color: Colors.black,
            ),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.people,
              color: Colors.black,
            ),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
  
  goToPageDetail(pid) async {
    print(pid);
    var temp = [];
    QuerySnapshot qn = await _firestoreInstance
        .collection('Property')
        .where('pid', isEqualTo: pid.toString())
        .get();
    setState(() {
      for (int i = 0; i < qn.docs.length; i++) {
        temp.add({
          "address": qn.docs[i]['address'],
          "bathroom": qn.docs[i]['bathroom'],
          "city": qn.docs[i]['city'],
          "description": qn.docs[i]['description'] ?? "",
          "owned-by": qn.docs[i]['owned-by'],
          "pid": qn.docs[i]['pid'],
          "postal": qn.docs[i]['postal'],
          "price": qn.docs[i]['price'],
          "img": qn.docs[i]['property-img'],
          "property-name": qn.docs[i]['property-name'],
          "room": qn.docs[i]['room'],
          "state": qn.docs[i]['state'],
          "status": qn.docs[i]['status'],
          "street": qn.docs[i]['street'],
          "updatedOn": qn.docs[i]['updatedOn'],
        });
      }
    });
    Navigator.push(context, MaterialPageRoute(builder: (context)=> PropertyDetail(temp[0])));
  }
}
