// ignore_for_file: avoid_unnecessary_containers, avoid_init_to_null

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/global/loading.dart';
import 'package:demo1/user/usermain.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class UserData extends StatefulWidget {
  const UserData({super.key});

  @override
  State<UserData> createState() => _UserDataState();
}

class _UserDataState extends State<UserData> {
  List<DropdownMenuItem<String>> get dropdownItems{
    List<DropdownMenuItem<String>> menuItems = [
      const DropdownMenuItem(value: "Male", child: Text("Male"), ),
      const DropdownMenuItem(value: "Female", child: Text("Female")),
      const DropdownMenuItem(value: "Other", child: Text("Other")),
    ];

    return menuItems;
  }

  sendUserDataToDB() async {
    final FirebaseAuth auth = FirebaseAuth.instance;
    var currentUser = auth.currentUser;

    CollectionReference collectionRef = FirebaseFirestore.instance.collection('UserAcc');
    return collectionRef.doc(currentUser!.email).set({
      "username": _usernameController.text,
      "phone": _phoneController.text,
      "dob": _dobController.text,
      "gender": selectedValue,
      "email": currentUser.email,
      "profile-img": ""
    }).then((value) => Fluttertoast.showToast(msg: 'User Created'))
    .catchError((error)=> Fluttertoast.showToast(msg: 'Something is wrong'));
    
  }
  
  final _dobController = TextEditingController();
  final _usernameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String? selectedValue = null;
  String username = '';
  int phone = 0;
  bool loading = false;

  @override
  void dispose(){
    _dobController.dispose();
    _usernameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return loading ? const Loading() : Scaffold(
      appBar: AppBar(
        title: const Text("User Information"),
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              child: const Text(
                'Before proceeding to the next step we would like you to fill up your information',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: "verdana_regular",
                )
              ),
            ),

            Container(
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    //username
                    Container( 
                      padding: const EdgeInsets.all(20),
                      alignment: Alignment.center,
                      
                      child: TextFormField(
                        validator: (val) => val!.isEmpty ? "Enter an username" : null,
                        onChanged: (val){
                          setState(() => username = val);
                        },
                        controller: _usernameController,
                        style: const TextStyle(
                          fontSize: 24,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          labelText: "Username",
                          focusColor: Colors.white,
                          border: const OutlineInputBorder(),
                          prefixIcon: const Icon(
                            Icons.person_outline_rounded,
                            color: Colors.grey,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1.0,
                              color: Colors.blue,
                            ),
                            borderRadius: BorderRadius.circular(10)
                          ),
                          fillColor: Colors.grey,

                          hintStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )             
                        ),
                      ),
                    ),

                    //phone
                    Container( 
                      padding: const EdgeInsets.all(20),
                      alignment: Alignment.center,
                      child: TextFormField(
                        keyboardType: TextInputType.phone,
                        validator: (val) {
                          if(val!.isEmpty){
                            return "Enter a phone number";
                          }
                          else if(val.length != 10){
                            return "A phone number should have 10 digit";
                          }else{
                            return null;
                          }
                        },
                        onChanged: (val){
                          setState(() => phone = int.parse(val));
                        },
                        controller: _phoneController,
                        style: const TextStyle(
                          fontSize: 24,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          labelText: "Phone",
                          focusColor: Colors.white,
                          border: const OutlineInputBorder(),
                          prefixIcon: const Icon(
                            Icons.phone,
                            color: Colors.grey,
                          ),
                          //errorText: 'Invalid Email',
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1.0,
                              color: Colors.blue,
                            ),
                            borderRadius: BorderRadius.circular(10)
                          ),
                          fillColor: Colors.grey,

                          hintStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )             
                        ),
                      ),
                    ),
                    
                    //dob
                    Container(
                      padding: const EdgeInsets.all(20),
                      child: TextFormField(
                        keyboardType: TextInputType.datetime,
                        controller: _dobController,
                        validator: (val) => val!.isEmpty ? "Select an date" : null,
                        style: const TextStyle(
                          fontSize: 24,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          labelText: "Date Of Birth(dd/mm/yyyy)",
                          focusColor: Colors.white,
                          border: const OutlineInputBorder(),
                          prefixIcon: const Icon(
                            Icons.calendar_month,
                            color: Colors.grey,
                          ),
                          //errorText: 'Invalid Email',
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1.0,
                              color: Colors.blue,
                            ),
                            borderRadius: BorderRadius.circular(10)
                          ),
                          fillColor: Colors.grey,

                          hintStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ) 
                          
                        ), 
                        onTap: () async {
                          final DateTime? picked = await showDatePicker(
                            context: context, 
                            initialDate: DateTime(DateTime.now().year - 18),
                            firstDate: DateTime(DateTime.now().year - 50),
                            lastDate: DateTime(DateTime.now().year),
                          );
                          if(picked != null){
                            setState(() {
                              _dobController.text = "${picked.day}/ ${picked.month}/ ${picked.year}";
                            });
                          }
                        },
                      ),
                    ),

                    //gender
                    Container(
                      padding: const EdgeInsets.all(20),
                      child: DropdownButtonFormField(
                        hint: const Text('Select gender'),
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide: const BorderSide(color: Colors.blue, width: 2),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          border: OutlineInputBorder(
                            borderSide: const BorderSide(color: Colors.blue, width: 2),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          filled: true,
                          fillColor: Colors.blue[100],
                        ),
                        validator: (value) => value == null ? "Select a gender" : null,
                        dropdownColor: Colors.blue[200],
                        value: selectedValue,
                        onChanged: (String? newValue) {
                          setState(() {
                            selectedValue = newValue!;
                          });
                        },
                        items: dropdownItems,
                      ),
                    ),
                    
                    //button
                    OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(200,50),
                        backgroundColor: const Color.fromARGB(255, 3, 109, 248),
                        side: const BorderSide(width: 2),         
                        
                      ),
                      onPressed: () async {
                        if(_formKey.currentState!.validate()){
                          setState(() {
                            loading = true;
                          });
                          sendUserDataToDB();
                          Navigator.push(
                            context, 
                            MaterialPageRoute(builder: (context) => const UserMain()),
                          );
                        }else{
                          setState(() {
                            loading = false;
                          });
                        }
                      },
                      child: Text(
                        "Submit".toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold
                        ),
                      ),
                    ) 
                  ],
                )              
              ),
            )
          ],
        ) 
      ),
    );
  }
}