// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_build_context_synchronously, no_leading_underscores_for_local_identifiers

import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/chat/chat.dart';
import 'package:demo1/authenticate/loginpage.dart';
import 'package:demo1/property/property_main.dart';
import 'package:demo1/user/changePassword.dart';
import 'package:demo1/user/editprofile.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:demo1/services/auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';

class UserMain extends StatefulWidget {
  const UserMain({super.key});

  @override
  State<UserMain> createState() => _UserMainState();
}

class _UserMainState extends State<UserMain> {
  var currentUser = FirebaseAuth.instance.currentUser;
  final AuthService _auth = AuthService();
  int _selectedIndex = 3;
  var email, username, img;
  bool change = false;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  @override
  void initState() {
    getData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: Text('User'),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            
            Container(
              margin: EdgeInsets.fromLTRB(0, 20, 0, 00),
              child: Center(
                child: Stack(
                  children: <Widget>[
                    showProfImg(),
                    Positioned(
                      right: 110,
                        child: GestureDetector(
                          onTap: (){
                            _selectImage();
                          },
                          child: CircleAvatar(
                            backgroundColor: Colors.blue[200],
                            child: Icon(Icons.add_a_photo, color: Colors.black,)
                          ),
                        ),
                      
                    ),
                    
                    
                  ],
                ),
              )
            ),
            
            Center(child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text("$username"),
            ),),
            
            //edit 
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
              margin: EdgeInsets.all(0),
              child: ElevatedButton.icon(
                icon: Icon(Icons.create_rounded),
                onPressed: (){
                  Navigator.push(
                    context, 
                    MaterialPageRoute(builder: (context) => const EditProfile()),
                  );
                },
                label: Text('Edit Profile'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[400],
                  minimumSize: Size(100,50),
                  fixedSize: Size(400, 50)
                ),         
              ),
            ),

            //change password
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
              margin: EdgeInsets.all(0),
              child: ElevatedButton.icon(
                icon: Icon(Icons.create_rounded),
                onPressed: (){
                  //_displayTextInputDialog(context);
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> ChangePassword()));
                },
                label: Text('Change Password'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue[80],
                  minimumSize: Size(100,50),
                  fixedSize: Size(400, 50)
                ),         
              ),
            ),
            
            Container(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
              margin: EdgeInsets.all(0),
              child: ElevatedButton.icon(
                icon: Icon(Icons.logout),
                onPressed: () async{
                  await _auth.signOut();
                  Navigator.push(
                    context, 
                    MaterialPageRoute(builder: (context) => const LoginPage()),
                  );
                },
                label: Text('Logout'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red[400],
                  minimumSize: Size(100,50),
                  fixedSize: Size(400, 50)
                ),         
              ),
            ),
          ],
        ),       //padding: EdgeInsets.all(20),     
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
  

  getData() async{
    email = currentUser!.email;
    QuerySnapshot qn= await FirebaseFirestore.instance.collection("UserAcc").where('email', isEqualTo: email).get();
    setState(() {
      username = qn.docs[0]['username'];
      img = qn.docs[0]['profile-img'];
    });
  }
  
  showProfImg() {
    return Center(
      child: Container(
        width: 200,
        height: 200,
        child: img == "" || img == null? CircleAvatar(
          child: Icon(Icons.person, size: 100,)
        ): CircleAvatar(
          backgroundImage: NetworkImage(img),
        )
        
      ),
    );
  }
  
  var tempImg;
  void _selectImage() async {
    final tempImg = await ImagePicker().pickImage(source: ImageSource.gallery);
    if(tempImg == null){
      Fluttertoast.showToast(msg: "No image selected");
    }else{
      //showAlertDialog(context);
      Reference ref = FirebaseStorage.instance.ref().child("profile/${tempImg.name}");
      await ref.putFile(File(tempImg.path));
      ref.getDownloadURL().then((value) {
        CollectionReference ref = FirebaseFirestore.instance.collection("UserAcc");
        ref.doc(email).update({"profile-img": value})
        .then((value) => Fluttertoast.showToast(msg: 'Profile Images Updated'))
        .catchError((onError)=> Fluttertoast.showToast(msg: 'Something went wrong'));
        
        img= value;
        //print(img);
        setState(() {
          showProfImg();
        });
      });
    }
  }

  showAlertDialog(BuildContext context) {
  // set up the buttons
  // ignore: unused_local_variable
    Widget cancelButton = TextButton(
      child: const Text("No"),
      onPressed:  () {
        Navigator.of(context).pop();
      },
    );
    Widget continueButton = TextButton(
      child: const Text("Yes"),
      onPressed:  () async{
        //print(tempImg.name);
          // Reference ref = FirebaseStorage.instance.ref().child("profile/${tempImg.name}");
          // await ref.putFile(File(tempImg.path));
          // ref.getDownloadURL().then((value) {
          //   CollectionReference ref = FirebaseFirestore.instance.collection("UserAcc");
          //   ref.doc(email).update({"profile-img": value})
          //   .then((value) => Fluttertoast.showToast(msg: 'Profile Images Updated'))
          //   .catchError((onError)=> Fluttertoast.showToast(msg: 'Something went wrong'));
            
          //   img= value;
          //   //print(img);
          //   setState(() {
          //     showProfImg();
          //   });
          // });
        Navigator.of(context).pop();
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text("Change profile image"),
      content: Text("Are you sure?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
  



  bool isValidPassword(String val){
    String  pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{6,}$';
    RegExp regExp = RegExp(pattern);
    return regExp.hasMatch(val);
  }
}