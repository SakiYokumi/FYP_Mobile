// ignore_for_file: prefer_const_constructors

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ChangePassword extends StatefulWidget {
  const ChangePassword({super.key});

  @override
  State<ChangePassword> createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  final _oldPassword = TextEditingController();
  final _newPassword = TextEditingController();
  final _reEnterPassword = TextEditingController();
  bool _isObscured = true;
  bool _isObscured2 = true;
  bool _isObscured3 = true;
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    _isObscured = true;
    _isObscured2 = true;
    _isObscured3 = true;
    super.initState();
  }

  @override
  void dispose(){
    _oldPassword.dispose();
    _newPassword.dispose();
    _reEnterPassword.dispose();
    super.dispose();
  }

  bool isValidPassword(String val){
    String  pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{6,}$';
    RegExp regExp = RegExp(pattern);
    return regExp.hasMatch(val);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        title: Text('Change Password'),
        backgroundColor: Colors.blue[400],
      ),
      body: SingleChildScrollView(     
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: Container(
                margin: EdgeInsets.fromLTRB(0, 30, 0, 0),
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(180),
                  border: Border.all(width: 4, color: Colors.blue,), 
                  
                ),            
                child: Icon(
                  Icons.lock,
                  color: Colors.blue,
                  size: 200,
                )
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Center(
                child: Text(
                  'Change Password'.toUpperCase(),
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                ),
              ),
            ),
            Center(
              child: Text(
                'Make Sure You Remember Your Password ',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.grey),
              ),
            ),

            Form(
              key: _formKey,
              child: Column(
                children: [
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: _oldPassword,
                          obscureText: _isObscured,
                          // validator: (val) {
                          //   if(isValidPassword(val!) == false){
                          //     return 'Password should be 6+ characters long';
                          //   } 
                          //   return null;
                          // },
                          style: TextStyle(
                            fontSize: 24,
                            color: Colors.blue,
                            fontWeight: FontWeight.w600,
                          ),
                          decoration: InputDecoration(
                            labelText: "Current Password",
                            focusColor: Colors.white,
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(
                              Icons.lock,
                              color: Colors.grey,
                            ),
                            suffixIcon: IconButton(
                              padding: const EdgeInsetsDirectional.only(end: 12.0),
                              onPressed: (){
                                setState(() {
                                  _isObscured =!_isObscured;
                                });
                              },
                              icon: _isObscured ? const Icon(Icons.visibility) : const Icon(Icons.visibility_off),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                width: 1.0,
                                color: Colors.blue,
                              ),
                              borderRadius: BorderRadius.circular(10)
                            ),
                            fillColor: Colors.grey,

                            hintStyle: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "verdana_regular",
                            ),

                            //create label
                            labelStyle: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "verdana_regular",
                            )             
                          ),
                        ),
                      ),

                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: _newPassword,
                          obscureText: _isObscured2,
                          // validator: (val) {
                          //   if(isValidPassword(val!) == false){
                          //     return 'Password should be 6+ characters long';
                          //   } 
                          //   return null;
                          // },
                          style: TextStyle(
                            fontSize: 24,
                            color: Colors.blue,
                            fontWeight: FontWeight.w600,
                          ),
                          decoration: InputDecoration(
                            labelText: "New Password",
                            focusColor: Colors.white,
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(
                              Icons.lock,
                              color: Colors.grey,
                            ),
                            suffixIcon: IconButton(
                              padding: const EdgeInsetsDirectional.only(end: 12.0),
                              onPressed: (){
                                setState(() {
                                  _isObscured2 =!_isObscured2;
                                });
                              },
                              icon: _isObscured2 ? const Icon(Icons.visibility) : const Icon(Icons.visibility_off),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                width: 1.0,
                                color: Colors.blue,
                              ),
                              borderRadius: BorderRadius.circular(10)
                            ),
                            fillColor: Colors.grey,

                            hintStyle: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "verdana_regular",
                            ),

                            //create label
                            labelStyle: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "verdana_regular",
                            )             
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: _reEnterPassword,
                          obscureText: _isObscured3,
                          validator: (val) => val != _newPassword.text ? 'Must be same with new password' : null,
                          style: TextStyle(
                            fontSize: 24,
                            color: Colors.blue,
                            fontWeight: FontWeight.w600,
                          ),
                          decoration: InputDecoration(
                            labelText: "Confirm Password",
                            focusColor: Colors.white,
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(
                              Icons.lock,
                              color: Colors.grey,
                            ),
                            suffixIcon: IconButton(
                              padding: const EdgeInsetsDirectional.only(end: 12.0),
                              onPressed: (){
                                setState(() {
                                  _isObscured3 =!_isObscured3;
                                });
                              },
                              icon: _isObscured3 ? const Icon(Icons.visibility) : const Icon(Icons.visibility_off),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                width: 1.0,
                                color: Colors.blue,
                              ),
                              borderRadius: BorderRadius.circular(10)
                            ),
                            fillColor: Colors.grey,

                            hintStyle: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "verdana_regular",
                            ),

                            //create label
                            labelStyle: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              fontFamily: "verdana_regular",
                            )             
                          ),
                        ),
                      ),
                      SizedBox(height: 20,),
                      Row(
                        children: [
                        
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
                              child: OutlinedButton(
                                style: OutlinedButton.styleFrom(
                                  minimumSize: const Size(100,80),
                                  backgroundColor: Colors.red[400],
                                  side: BorderSide(width: 2),                        
                                ),
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: Text(
                                  "Cancel".toUpperCase(),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                            ),
                          ),

                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
                              child: OutlinedButton(
                                style: OutlinedButton.styleFrom(
                                  minimumSize: const Size(100,80),
                                  backgroundColor: Colors.blue[400],
                                  side: BorderSide(width: 2),         
                                  
                                ),
                                onPressed: () async {
                                  Fluttertoast.showToast(msg: "Loading ...");
                                  if(_formKey.currentState!.validate()){
                                    
                                    var currentUser = FirebaseAuth.instance.currentUser;
                                    updatePassword(currentUser!.email, _oldPassword.text, _newPassword.text);
                                  }
                                },
                                child: Text(
                                  "Confirm".toUpperCase(),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold
                                  ),
                                ),
                              ),
                            ),
                          ),

                        ],
                      )
                    ],
                  ),
                ],
              ),    
            ),
          ],
        ),
      ),
    );
  }
  
  void updatePassword(String? email, String oldPass, String newPass) async {
    try{
      final user = FirebaseAuth.instance.currentUser;
      final cred = EmailAuthProvider.credential(email: email!, password: oldPass);

      user!.reauthenticateWithCredential(cred).then((value){
        user.updatePassword(newPass).then((value) {
          Fluttertoast.showToast(msg: "Password Updated");
          Navigator.pop(context);
        }).catchError((e){
          Fluttertoast.showToast(msg: "Failed to update password");
        });
      }).catchError((e){
        Fluttertoast.showToast(msg: "Current Password is Invalid");
      });
    }on FirebaseAuthException catch (e){
      Fluttertoast.showToast(msg: "Oops! Something went wrong $e");
    }
  }
}