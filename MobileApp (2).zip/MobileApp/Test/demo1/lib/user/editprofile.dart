// ignore_for_file: prefer_const_constructors

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';

import 'package:demo1/chat/chat.dart';
import 'package:demo1/property/property_main.dart';
//import 'package:demo1/services/auth.dart';
import 'package:demo1/user/usermain.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class EditProfile extends StatefulWidget {
  const EditProfile({super.key});

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  //final AuthService _auth = AuthService();
  int _selectedIndex = 3;
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    update();
  }

  void update(){
    if(_selectedIndex == 0){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Homepage()),
      );
    }
    else if(_selectedIndex == 1){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const PropertyMain()),
      );
    }
    else if(_selectedIndex == 2){
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const Chat()),
      );
    }
    else if(_selectedIndex == 3){
      _selectedIndex == 3;
      Navigator.push(
        context, 
        MaterialPageRoute(builder: (context) => const UserMain()),
      );
    }
  }

  updateData(){
    CollectionReference collectionRef = FirebaseFirestore.instance.collection('UserAcc');
    return collectionRef.doc(FirebaseAuth.instance.currentUser!.email).update(
      {
        "username": _usernameController!.text,
        "phone": _phoneController!.text
      }
    ).then((value) => showAlertDialog(context));//Fluttertoast.showToast(msg: "Update Successful", backgroundColor: Colors.green, textColor: Colors.white)); 
    
  }

  setDataToTextField(data){
    //print(data['username']);
    return 
    Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Container(
          padding: const EdgeInsets.all(20),
          alignment: Alignment.center,
          child: TextFormField(
            validator: (val) => val!.isEmpty ? "Enter an username" : null,
            controller: _usernameController = TextEditingController(text: data['username']),
            style: const TextStyle(
              fontSize: 24,
              color: Colors.blue,
              fontWeight: FontWeight.w600,
            ),
            decoration: InputDecoration(
              labelText: "Username",
              focusColor: Colors.white,
              border: const OutlineInputBorder(),
              prefixIcon: const Icon(
                Icons.person_outline_rounded,
                color: Colors.grey,
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(
                  width: 1.0,
                  color: Colors.blue,
                ),
                borderRadius: BorderRadius.circular(10)
              ),
              fillColor: Colors.grey,

              hintStyle: const TextStyle(
                color: Colors.grey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
                fontFamily: "verdana_regular",
              ),

              //create label
              labelStyle: const TextStyle(
                color: Colors.grey,
                fontSize: 16,
                fontWeight: FontWeight.w400,
                fontFamily: "verdana_regular",
              )             
            ),
          ),
        ),

        Center(
          child: Container( 
            padding: const EdgeInsets.all(20),
            alignment: Alignment.center,
            child: TextFormField(
              keyboardType: TextInputType.phone,
              validator: (val) {
                if(val!.isEmpty){
                  return "Enter a phone number";
                }
                else if(val.length != 10){
                  return "A phone number should have 10 digit";
                }else{
                  return null;
                }
              },
              controller: _phoneController = TextEditingController(text: data['phone']),
              style: const TextStyle(
                fontSize: 24,
                color: Colors.blue,
                fontWeight: FontWeight.w600,
              ),
              decoration: InputDecoration(
                labelText: "Phone",
                focusColor: Colors.white,
                border: const OutlineInputBorder(),
                prefixIcon: const Icon(
                  Icons.person_outline_rounded,
                  color: Colors.grey,
                ),
                //errorText: 'Invalid Email',
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(
                    width: 1.0,
                    color: Colors.blue,
                  ),
                  borderRadius: BorderRadius.circular(10)
                ),
                fillColor: Colors.grey,

                hintStyle: const TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  fontFamily: "verdana_regular",
                ),

                //create label
                labelStyle: const TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                  fontFamily: "verdana_regular",
                )             
              ),
            ),
          ),
        ),

        //button
        Center(
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(200,50),
              backgroundColor: const Color.fromARGB(255, 3, 109, 248),
              side: const BorderSide(width: 2),                           
            ),
            onPressed: () {
              updateData();
            },
            child: Text(
              "Update".toUpperCase(),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold
              ),
            ),
          )
        ),
      ],
    );
  }

  showAlertDialog(BuildContext context) {

  // set up the buttons
  // ignore: unused_local_variable
  Widget cancelButton = TextButton(
    child: Text("Cancel"),
    onPressed:  () {
      Navigator.of(context).pop();
    },
  );
  Widget continueButton = TextButton(
    child: Text("Continue"),
    onPressed:  () {
      update();
    },
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Status"),
    content: Text("Update Successfully"),
    actions: [
      //cancelButton,
      continueButton,
    ],
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
  
  TextEditingController ?_usernameController ;
  TextEditingController ?_phoneController;
  //TextEditingController ?_usernameController;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Edit Profile'),
      ),
      body: SingleChildScrollView(
        //Type your code here 
        child: StreamBuilder(
          stream: FirebaseFirestore.instance.collection("UserAcc").doc(FirebaseAuth.instance.currentUser!.email).snapshots(),
          builder: (BuildContext context, AsyncSnapshot snapshot) {         
            var data = snapshot.data;
            if(data==null){
              return Center(child: CircularProgressIndicator(),);
            }
            //print(data['username']);
            return setDataToTextField(data);
            
          }
        ),  
      ),

      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue[600],
        unselectedItemColor: Colors.white70,
        items: const <BottomNavigationBarItem>[
          
          BottomNavigationBarItem(          
            icon: Icon(Icons.home, color: Colors.black,),
            label: 'Home', 
            
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business, color: Colors.black,),
            label: 'Property',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_outlined, color: Colors.black,),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people, color: Colors.black,),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}