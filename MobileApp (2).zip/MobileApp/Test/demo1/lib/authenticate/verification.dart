// ignore_for_file: unused_import

import 'package:demo1/authenticate/newpassword.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';

class Verification extends StatefulWidget {
  const Verification({super.key});

  @override
  State<Verification> createState() => _VerificationState();
}

class _VerificationState extends State<Verification> {
  final optController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String verCode = "1234";

  @override
  void dispose(){
    optController.dispose();
    super.dispose();
  } 


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Verification"),
      ),

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Center(
            child: Container(
              margin: const EdgeInsets.fromLTRB(0, 30, 0, 25),
              padding: const EdgeInsets.all(30),
              width: 250,
              height: 250,            
              decoration: BoxDecoration(
                border: Border.all(color: Colors.green, width: 4.0),
                borderRadius: const BorderRadius.all(
                  Radius.circular(180)
                )  
              ),
              child: SvgPicture.asset(
                "assets/images/send_email.svg",
                color: Colors.green,
              ),
            ),
          ),
          const Text(
            "Enter the verification code sent to your email",
            style: TextStyle(
              color: Colors.grey,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: "verdana_regular",
            )
          ),

          Form(
            key: _formKey,
            child: Column(
              children: [
                Center(
                  child: Container( 
                    padding: const EdgeInsets.all(20),
                    alignment: Alignment.center,
                    child: TextFormField(
                      keyboardType: TextInputType.number,
                      validator: (val){
                        if(val == null || val.isEmpty){
                          return "Invalid Verification Code";
                        }else if(val.length != 4){
                          return "Verification code must be 4 digit";
                        }
                        return null;
                      },
                      controller: optController,
                      style: const TextStyle(
                        fontSize: 24,
                        color: Colors.blue,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: InputDecoration(
                        labelText: "Verification code",
                        focusColor: Colors.white,
                        border: const OutlineInputBorder(),
                        prefixIcon: const Icon(
                          Icons.email_outlined,
                          color: Colors.grey,
                        ),
                        
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 1.0,
                            color: Colors.blue,
                          ),
                          borderRadius: BorderRadius.circular(10)
                        ),
                        fillColor: Colors.grey,

                        hintStyle: const TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          fontFamily: "verdana_regular",
                        ),

                        //create label
                        labelStyle: const TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          fontFamily: "verdana_regular",
                        )             
                      ),
                    ),
                  ),
                ),

                // Center(
                //   child: OtpTextField(
                //     numberOfFields: 4,
                //     borderColor: Color(0xFF512DA8),
                //     showFieldAsBox: true,
                //     filled: true,
                //     fillColor: Colors.black.withOpacity(0.3),

                //     onCodeChanged: (val){
                      
                //     },
                //     keyboardType: TextInputType.number,
                //     onSubmit: (val){
                //       if(val.length != 4 && val != verCode){
                //         print("Verification code ");
                //       }
                //       showDialog(
                //         context: context, 
                //         builder: (context){
                //           return AlertDialog(
                //             title: const Text("Verification Code"),
                //             content: Text("Code entered is $val"),
                //           );
                //         }
                //       );
                //     }
                //   )
                // ),

                Center(
                  child: Container(
                    margin: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(200,50),
                        backgroundColor: const Color.fromARGB(255, 3, 109, 248),
                        side: const BorderSide(width: 2),         
                        
                      ),
                      onPressed: (){
                        if(_formKey.currentState!.validate()){
                          // ScaffoldMessenger.of(context).showSnackBar(
                          //   const SnackBar(content: Text('Processing Data')),
                          // );
                          Navigator.push(
                            context, 
                            MaterialPageRoute(builder: (context) => const NewPassword()),
                          );
                        }
                      },
                      child: Text(
                        "Verify".toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold
                        ),
                      ),
                    )
                  )
                  
                ),
              ],
            )
          )
        ],
      )
    );
  }
}