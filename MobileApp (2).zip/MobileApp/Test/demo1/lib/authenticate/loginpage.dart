// ignore_for_file: prefer_const_constructors, use_build_context_synchronously

import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:demo1/Home/homepage.dart';
import 'package:demo1/admin/adminmain.dart';
import 'package:demo1/authenticate/forgotpassword.dart';
import 'package:demo1/user/userdata.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:demo1/authenticate/signup.dart';
import 'package:demo1/global/loading.dart';
import 'package:fluttertoast/fluttertoast.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _loginKey = GlobalKey<FormState>();
  bool _isObscured = true;
  bool loading = false;
  String email = '';
  String password = '';
  String error = '';
  
  @override
  void dispose(){
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }   

  @override void initState() {
    super.initState();
    _isObscured = true;
  }

  //Account acc = Account();
  loginWithEmailAndPassword() async {
    try {
      // ignore: unused_local_variable
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: _emailController.text, password: _passwordController.text);
      // ignore: unused_local_variable
      if (_emailController.text.toLowerCase() == 'admin@admin.com' &&
          _passwordController.text.toLowerCase() == 'admin123') {
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => AdminMain()));
      }
      else {
        isDocExsist();
      } 
      //print("Password is $acc.getPassword");
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        Fluttertoast.showToast(msg: 'No user found for that email.');
      } else if (e.code == 'wrong-password') {
        Fluttertoast.showToast(msg: 'Wrong password provided for that user.');
      }
    }
  }

  Future isDocExsist() async {
    DocumentSnapshot<Map<String, dynamic>> document = await FirebaseFirestore.instance
    .collection("UserAcc").doc(_emailController.text).get();

    if(document.exists){
      Navigator.push(context, MaterialPageRoute(builder: (context) => const Homepage()),).then((value) => null);
      //Navigator.push(context, MaterialPageRoute(builder: (context) => const Testing()),);
    }else {
      Navigator.push(context, MaterialPageRoute(builder: (context) => const UserData()),);
    }
  }

  bool isValidPassword(String val){
    String  pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{6,}$';
    RegExp regExp = RegExp(pattern);
    return regExp.hasMatch(val);
  }
  

  @override
  Widget build(BuildContext context) {
    return loading ? Loading() : Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: Container(
                margin: EdgeInsets.fromLTRB(0, 30, 0, 0),
                width: 250,
                height: 250,            
                child: Icon(
                  Icons.person_pin,
                  color: Colors.blue,
                  size: 250,
                ),
              ),
            ),

            Form(
              key: _loginKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //email text
                  Center(
                    child: Container( 
                      padding: EdgeInsets.all(20),
                      alignment: Alignment.center,
                      child: TextFormField(
                        validator: (val) => val!.isEmpty ? "Enter an email" : null,
                        onChanged: (val){
                          setState(() => email = val);
                        },
                        controller: _emailController,
                        style: TextStyle(
                          fontSize: 24,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          labelText: "Email",
                          focusColor: Colors.white,
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(
                            Icons.email_outlined,
                            color: Colors.grey,
                          ),
                          //errorText: 'Invalid Email',
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1.0,
                              color: Colors.blue,
                            ),
                            borderRadius: BorderRadius.circular(10)
                          ),
                          fillColor: Colors.grey,

                          hintStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )             
                        ),
                      ),
                    ),
                  ),

                  //password text
                  Center(
                    child: Container( 
                      padding: EdgeInsets.all(20),
                      alignment: Alignment.center,
                      child: TextFormField(
                        obscureText: _isObscured,
                        validator: (val) => isValidPassword(val!) ? 'Enter a password 6+ chars long' : null,
                        onChanged: (val){
                          setState(() => password = val);
                        },
                        controller: _passwordController,
                        style: TextStyle(
                          fontSize: 24,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          labelText: "Password",
                          focusColor: Colors.white,
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(
                            Icons.lock,
                            color: Colors.grey,
                          ),
                          suffixIcon: IconButton(
                            padding: const EdgeInsetsDirectional.only(end: 12.0),
                            onPressed: (){
                              setState(() {
                                _isObscured =!_isObscured;
                              });
                            },
                            icon: _isObscured ? const Icon(Icons.visibility) : const Icon(Icons.visibility_off),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1.0,
                              color: Colors.blue,
                            ),
                            borderRadius: BorderRadius.circular(10)
                          ),
                          fillColor: Colors.grey,

                          hintStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )             
                        ),
                      ),
                    ),
                  ),

                  Row(
                    textDirection: TextDirection.rtl,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 20.0, 20.0),
                        child: 
                          RichText(
                          text: TextSpan(
                            text: "Forgot Password",
                            style: TextStyle(color: Colors.blue),
                            recognizer: TapGestureRecognizer()
                            ..onTap = (){
                              Navigator.push(
                                context, 
                                MaterialPageRoute(builder: (context) => const ForgotPassword()),
                              );                           
                            }
                          ),
                        ),         
                      )                  
                    ]
                  ),

                  Center(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(200,50),
                        backgroundColor: Color.fromARGB(255, 3, 109, 248),
                        side: BorderSide(width: 2),         
                        
                      ),
                      onPressed: () async {
                        if(_loginKey.currentState!.validate()){
                          loginWithEmailAndPassword();
                        }
                      },
                      child: Text(
                        "Login".toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold
                        ),
                      ),
                    )
                  ),

                  Container(
                    margin: EdgeInsets.only(top: 10),
                    child: Center(
                      child: RichText(
                      
                        text: TextSpan(
                          // ignore: prefer_const_literals_to_create_immutables

                          children: [
                            
                            TextSpan(                          
                              text: "Don't have an account?",
                              style: TextStyle(color: Colors.black),  
                            ),
                            TextSpan(
                              text: "Register",
                              style: TextStyle(
                                color: Colors.blue, 
                                decoration: TextDecoration.underline,
                              ),
                              recognizer: TapGestureRecognizer()
                              ..onTap = (){
                                Navigator.push(
                                  context, 
                                  MaterialPageRoute(builder: (context) => const SignUp()),
                                );
                              }
                            )
                          ]
                        )
                      ),
                    ),
                  ),
                ],
              )
            ),        
          ],
        ),
      ),
    );
  }
}

