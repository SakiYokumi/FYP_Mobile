import 'package:demo1/authenticate/loginpage.dart';
import 'package:flutter/material.dart';
//import 'package:flutter_svg/flutter_svg.dart';

class NewPassword extends StatefulWidget {
  const NewPassword({super.key});

  @override
  State<NewPassword> createState() => _NewPasswordState();
}

class _NewPasswordState extends State<NewPassword> {
  final passwordController = TextEditingController();
  final reenterController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isObscured1 = true;
  bool _isObscured2 = true;

  @override
  void dispose() {
    passwordController.dispose();
    reenterController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("New Password"),
      ),
      body: Column(
        //mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Container(
                margin: const EdgeInsets.fromLTRB(0, 30, 0, 25),
                padding: const EdgeInsets.all(30),
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.black, width: 4.0),
                    borderRadius: const BorderRadius.all(Radius.circular(180))),
                child: const Icon(
                  Icons.lock,
                  size: 150,
                )),
          ),
          Form(
              key: _formKey,
              child: Column(
                children: [
                  //password
                  Container(
                    padding: const EdgeInsets.all(20),
                    alignment: Alignment.center,
                    child: TextFormField(
                      obscureText: _isObscured1,
                      validator: (val) {
                        if (val == null || val.isEmpty) {
                          return "Invalid Password";
                        }else if(val.length < 6){
                          return "Password length must more that 6";
                        }
                        return null;
                      },
                      controller: passwordController,
                      style: const TextStyle(
                        fontSize: 24,
                        color: Colors.blue,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: InputDecoration(
                          labelText: "Password",
                          focusColor: Colors.white,
                          border: const OutlineInputBorder(),
                          prefixIcon: const Icon(
                            Icons.lock,
                            color: Colors.grey,
                          ),
                          suffixIcon: IconButton(
                            padding:
                                const EdgeInsetsDirectional.only(end: 12.0),
                            onPressed: () {
                              setState(() {
                                _isObscured1 = !_isObscured1;
                              });
                            },
                            icon: _isObscured1
                                ? const Icon(Icons.visibility)
                                : const Icon(Icons.visibility_off),
                          ),
                          focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                width: 1.0,
                                color: Colors.blue,
                              ),
                              borderRadius: BorderRadius.circular(10)),
                          fillColor: Colors.grey,
                          hintStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )),
                    ),
                  ),

                  //reenter password
                  Container(
                    padding: const EdgeInsets.all(20),
                    alignment: Alignment.center,
                    child: TextFormField(
                      obscureText: _isObscured2,
                      validator: (val) {
                        if (val == null || val.isEmpty) {
                          return "Invalid Password";
                        }else if(val.length < 6){
                          return "Password length must more that 6";
                        } 
                        else if (val != passwordController.text) {
                          return "Not Same Password";
                        }
                        return null;
                      },
                      controller: reenterController,
                      style: const TextStyle(
                        fontSize: 24,
                        color: Colors.blue,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: InputDecoration(
                          labelText: "Re-enter Password",
                          focusColor: Colors.white,
                          border: const OutlineInputBorder(),
                          prefixIcon: const Icon(
                            Icons.lock,
                            color: Colors.grey,
                          ),
                          suffixIcon: IconButton(
                            padding:
                                const EdgeInsetsDirectional.only(end: 12.0),
                            onPressed: () {
                              setState(() {
                                _isObscured2 = !_isObscured2;
                              });
                            },
                            icon: _isObscured2
                                ? const Icon(Icons.visibility)
                                : const Icon(Icons.visibility_off),
                          ),
                          focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(
                                width: 1.0,
                                color: Colors.blue,
                              ),
                              borderRadius: BorderRadius.circular(10)),
                          fillColor: Colors.grey,
                          hintStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: const TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )),
                    ),
                  ),

                  //button
                  SizedBox(
                      width: double.infinity,
                      child: Container(
                          margin: const EdgeInsets.fromLTRB(20, 0, 20, 0),
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              minimumSize: const Size(200, 50),
                              backgroundColor:
                                  const Color.fromARGB(255, 3, 109, 248),
                              side: const BorderSide(width: 2),
                            ),
                            onPressed: () {
                              if (_formKey.currentState!.validate()) {
                                // ScaffoldMessenger.of(context).showSnackBar(
                                //   const SnackBar(
                                //       content: Text('Processing Data')),
                                // );
                                // AlertDialog(
                                //   title: const Text('Password Updated'),
                                //   content: SingleChildScrollView(
                                //     child: ListBody(
                                //       children: const <Widget>[
                                //         Text('Password Updated Successfully'),
                                //       ],
                                //     ),
                                //   ),
                                //   actions: <Widget>[
                                //     TextButton(
                                //       child: const Text(('Login')),
                                      //onPressed: (){
                                        Navigator.push(
                                        context, 
                                        MaterialPageRoute(builder: (context) => const LoginPage()),
                                        );
                                //       }
                                //     ),                                     
                                //   ],
                                // );
                              }
                            },
                            child: Text(
                              "Update New Password".toUpperCase(),
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold),
                            ),
                          )))
                ],
              )),
        ],
      ),
    );
  }
}
