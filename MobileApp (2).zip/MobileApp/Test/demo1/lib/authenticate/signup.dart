// ignore_for_file: prefer_const_constructors

import 'package:demo1/authenticate/verfiry.dart';
import 'package:demo1/global/loading.dart';
import 'package:demo1/authenticate/loginpage.dart';
import 'package:demo1/services/auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  //final AuthService _auth = AuthService();
  final _usernameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _phoneController = TextEditingController();
  final _reenterController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  String email = '';
  String password = '';
  String error = '';
  String username = '';
  int phone = 0;
  bool loading = false;
  bool _isObscured1 = true;
  bool _isObscured2 = true; 

  singUP() async{
    try {
      UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password
      );
      // User? user = credential.user;
      //await DatabaseService(uid: user!.uid).updateUserData(user.uid, email ,username, phone);

      // ignore: use_build_context_synchronously
      Navigator.push(context, MaterialPageRoute(builder: (context) => const Verify()),);
    } on FirebaseAuthException catch (e) {
      setState(() {
        loading = false;
      });
      if (e.code == 'weak-password') {
        Fluttertoast.showToast(msg: 'The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        Fluttertoast.showToast(msg: 'The account already exists for that email.');
      }
    } catch (e) {
      setState(() {
        loading = false;
      });
      Fluttertoast.showToast(msg: 'OOPs! Something went wrong.');
    }
  }

  @override
  void dispose(){
    _phoneController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _usernameController.dispose();
    _reenterController.dispose();
    super.dispose();
  } 

  @override
  Widget build(BuildContext context) {
    return loading? Loading() : Scaffold(
      appBar: AppBar(
        title: Text("Register"),
      ),

      body: SingleChildScrollView(
        child: Column(
          children: [ 
            Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  //username
                  // Center(
                  //   child: Container( 
                  //     padding: EdgeInsets.all(20),
                  //     alignment: Alignment.center,
                      
                  //     child: TextFormField(
                  //       validator: (val) => val!.isEmpty ? "Enter an username" : null,
                  //       onChanged: (val){
                  //         setState(() => username = val);
                  //       },
                  //       controller: _usernameController,
                  //       style: TextStyle(
                  //         fontSize: 24,
                  //         color: Colors.blue,
                  //         fontWeight: FontWeight.w600,
                  //       ),
                  //       decoration: InputDecoration(
                  //         labelText: "Username",
                  //         focusColor: Colors.white,
                  //         border: OutlineInputBorder(),
                  //         prefixIcon: Icon(
                  //           Icons.person_outline_rounded,
                  //           color: Colors.grey,
                  //         ),
                  //         focusedBorder: OutlineInputBorder(
                  //           borderSide: const BorderSide(
                  //             width: 1.0,
                  //             color: Colors.blue,
                  //           ),
                  //           borderRadius: BorderRadius.circular(10)
                  //         ),
                  //         fillColor: Colors.grey,

                  //         hintStyle: TextStyle(
                  //           color: Colors.grey,
                  //           fontSize: 16,
                  //           fontWeight: FontWeight.w400,
                  //           fontFamily: "verdana_regular",
                  //         ),

                  //         //create label
                  //         labelStyle: TextStyle(
                  //           color: Colors.grey,
                  //           fontSize: 16,
                  //           fontWeight: FontWeight.w400,
                  //           fontFamily: "verdana_regular",
                  //         )             
                  //       ),
                  //     ),
                  //   ),
                  // ),

                  // //phone
                  // Center(
                  //   child: Container( 
                  //     padding: EdgeInsets.all(20),
                  //     alignment: Alignment.center,
                  //     child: TextFormField(
                  //       keyboardType: TextInputType.phone,
                  //       validator: (val) {
                  //         if(val!.isEmpty){
                  //           return "Enter a phone number";
                  //         }
                  //         else if(val.length != 10){
                  //           return "A phone number should have 10 digit";
                  //         }else{
                  //           return null;
                  //         }
                  //       },
                  //       onChanged: (val){
                  //         setState(() => phone = int.parse(val));
                  //       },
                  //       controller: _phoneController,
                  //       style: TextStyle(
                  //         fontSize: 24,
                  //         color: Colors.blue,
                  //         fontWeight: FontWeight.w600,
                  //       ),
                  //       decoration: InputDecoration(
                  //         labelText: "Phone",
                  //         focusColor: Colors.white,
                  //         border: OutlineInputBorder(),
                  //         prefixIcon: Icon(
                  //           Icons.person_outline_rounded,
                  //           color: Colors.grey,
                  //         ),
                  //         //errorText: 'Invalid Email',
                  //         focusedBorder: OutlineInputBorder(
                  //           borderSide: const BorderSide(
                  //             width: 1.0,
                  //             color: Colors.blue,
                  //           ),
                  //           borderRadius: BorderRadius.circular(10)
                  //         ),
                  //         fillColor: Colors.grey,

                  //         hintStyle: TextStyle(
                  //           color: Colors.grey,
                  //           fontSize: 16,
                  //           fontWeight: FontWeight.w400,
                  //           fontFamily: "verdana_regular",
                  //         ),

                  //         //create label
                  //         labelStyle: TextStyle(
                  //           color: Colors.grey,
                  //           fontSize: 16,
                  //           fontWeight: FontWeight.w400,
                  //           fontFamily: "verdana_regular",
                  //         )             
                  //       ),
                  //     ),
                  //   ),
                  // ),


                  //email text
                  Center(
                    child: Container( 
                      padding: EdgeInsets.all(20),
                      alignment: Alignment.center,
                      child: TextFormField(
                        validator: (val) => val!.isEmpty ? "Enter an email" : null,
                        onChanged: (val){
                          setState(() => email = val);
                        },
                        controller: _emailController,
                        style: TextStyle(
                          fontSize: 24,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          labelText: "Email",
                          focusColor: Colors.white,
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(
                            Icons.email_outlined,
                            color: Colors.grey,
                          ),
                          //errorText: 'Invalid Email',
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1.0,
                              color: Colors.blue,
                            ),
                            borderRadius: BorderRadius.circular(10)
                          ),
                          fillColor: Colors.grey,

                          hintStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )             
                        ),
                      ),
                    ),
                  ),

                  //password text
                  Center(
                    child: Container( 
                      padding: EdgeInsets.all(20),
                      alignment: Alignment.center,
                      child: TextFormField(
                        obscureText: _isObscured1,
                        onChanged: (val){
                          setState(() => password = val);
                        },
                        validator: (val) => val!.length < 6 ? 'Enter a password 6+ chars long' : null,
                        controller: _passwordController,
                        style: TextStyle(
                          fontSize: 24,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          labelText: "Password",
                          focusColor: Colors.white,
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(
                            Icons.lock,
                            color: Colors.grey,
                          ),
                          suffixIcon: IconButton(
                            padding: const EdgeInsetsDirectional.only(end: 12.0),
                            onPressed: (){
                              setState(() {
                                _isObscured1 =!_isObscured1;
                              });
                            },
                            icon: _isObscured1 ? const Icon(Icons.visibility) : const Icon(Icons.visibility_off),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1.0,
                              color: Colors.blue,
                            ),
                            borderRadius: BorderRadius.circular(10)
                          ),
                          fillColor: Colors.grey,

                          hintStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )             
                        ),
                      ),
                    ),
                  ),

                  //Re-enter Password
                  Center(
                    child: Container( 
                      padding: EdgeInsets.all(20),
                      alignment: Alignment.center,
                      child: TextFormField(
                        obscureText: _isObscured2,
                        validator: (val){
                          if(val == null || val.isEmpty && val.length < 6){
                            return "Invalid Password";
                          }
                          else if(val != _passwordController.text){
                            return "Not Same Password";
                          }
                          return null;
                        },
                        controller: _reenterController,
                        style: TextStyle(
                          fontSize: 24,
                          color: Colors.blue,
                          fontWeight: FontWeight.w600,
                        ),
                        decoration: InputDecoration(
                          labelText: "Re-enter Password",
                          focusColor: Colors.white,
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(
                            Icons.lock,
                            color: Colors.grey,
                          ),
                          suffixIcon: IconButton(
                            padding: const EdgeInsetsDirectional.only(end: 12.0),
                            onPressed: (){
                              setState(() {
                                _isObscured2 =!_isObscured2;
                              });
                            },
                            icon: _isObscured2 ? const Icon(Icons.visibility) : const Icon(Icons.visibility_off),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(
                              width: 1.0,
                              color: Colors.blue,
                            ),
                            borderRadius: BorderRadius.circular(10)
                          ),
                          fillColor: Colors.grey,

                          hintStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          ),

                          //create label
                          labelStyle: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                            fontWeight: FontWeight.w400,
                            fontFamily: "verdana_regular",
                          )             
                        ),
                      ),
                    ),
                  ),

                  Center(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(200,50),
                        backgroundColor: Color.fromARGB(255, 3, 109, 248),
                        side: BorderSide(width: 2),         
                        
                      ),
                      onPressed: () async {
                        if(_formKey.currentState!.validate()){
                          setState(() {
                            loading = true;
                          });
                          singUP();
                        }
                      },
                      child: Text(
                        "Register".toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold
                        ),
                      ),
                    )
                  ),

                  Container(
                    margin: EdgeInsets.only(top: 10),
                    child: Center(
                      child: RichText(
                      
                        text: TextSpan(
                          // ignore: prefer_const_literals_to_create_immutables

                          children: [
                            
                            TextSpan(                          
                              text: "Already have an account?",
                              style: TextStyle(color: Colors.black),  
                            ),
                            TextSpan(
                              text: "Login",
                              style: TextStyle(
                                color: Colors.blue, 
                                decoration: TextDecoration.underline,
                              ),
                              recognizer: TapGestureRecognizer()
                              ..onTap = (){
                                Navigator.push(
                                  context, 
                                  MaterialPageRoute(builder: (context) => const LoginPage()),
                                );
                              }
                            )
                          ]
                        )
                      ),
                    ),
                  ),

                  //Text('Email ${emailController.text} pass1 ${passwordController.text} pass2 ${reenterController.text}' )
                ],
              )
            )       
          ],
        ), 
      )
    );
  }
}