// ignore_for_file: prefer_const_constructors

//import 'dart:ffi';

import 'package:demo1/authenticate/verification.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({super.key});

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  final emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  
  @override
  void dispose(){
    emailController.dispose();
    super.dispose();
  } 

  bool validateEmail(var val){

    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Forgot Passsword"),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          //icon
          Center(
            child: Container(
              margin: EdgeInsets.fromLTRB(0, 30, 0, 25),
              padding: EdgeInsets.all(30),
              width: 250,
              height: 250,            
              decoration: BoxDecoration(
                border: Border.all(color: Colors.black, width: 4.0),
                borderRadius: BorderRadius.all(
                  Radius.circular(180)
                )  
              ),
              child: SvgPicture.asset(
                "assets/images/mailbox.svg",
              ),
            ),
          ),
          Center(
            child: Text(
              "Forgot Your Password?",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 28,
              ),
            ),
          ),

          Center(
            //child: Container(
              //margin: EdgeInsets.fromLTRB(0, 0, 0, 25),
              child: Text(
                "Enter your email address to ",
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 20,
                  fontWeight: FontWeight.w400,
                  fontFamily: "verdana_regular",
                ),
              ),
            //),           
          ),
          Center(
            child: Container(
              padding: EdgeInsets.all(0),
              margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
              child: Text(
                "retrieve your password",
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 20,
                  fontWeight: FontWeight.w400,
                  fontFamily: "verdana_regular",
                ),
              ),
            ),           
          ),
          Form(
            key: _formKey,
            child: Column(
              children: [
                Center(
                  child: Container( 
                    padding: EdgeInsets.all(20),
                    alignment: Alignment.center,
                    child: TextFormField(
                      validator: (val){
                        //bool validate = validateEmail(val);
                        if(val == null || val.isEmpty){
                          return "Invalid Email";
                        }
                        // else if(validate == false){
                        //   return "Invalid Email";
                        // }
                        return null;
                      },
                      controller: emailController,
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.blue,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: InputDecoration(
                        labelText: "Email",
                        focusColor: Colors.white,
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(
                          Icons.lock,
                          color: Colors.grey,
                        ),
                        //errorText: 'Invalid Email',
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            width: 1.0,
                            color: Colors.blue,
                          ),
                          borderRadius: BorderRadius.circular(10)
                        ),
                        fillColor: Colors.grey,

                        hintStyle: TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          fontFamily: "verdana_regular",
                        ),

                        //create label
                        labelStyle: TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                          fontWeight: FontWeight.w400,
                          fontFamily: "verdana_regular",
                        )             
                      ),
                    ),
                  ),
                ),

                Center(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size(200,50),
                      backgroundColor: Color.fromARGB(255, 3, 109, 248),
                      side: BorderSide(width: 2),         
                      
                    ),
                    onPressed: (){
                      if(_formKey.currentState!.validate()){
                        resetPassword();
                        Navigator.push(
                          context, 
                          MaterialPageRoute(builder: (context) => const Verification()),
                        );
                      }
                    },
                    child: Text(
                      "reset password".toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold
                      ),
                    ),
                  )
                ),
              ],
            )
          )
        ],
      ),
    );
  }
  
  Future resetPassword() async{
    showDialog(
      context: context, 
      barrierDismissible: false,
      builder: (context) => Center(child: CircularProgressIndicator(),)
    );

    try{
      await FirebaseAuth.instance.sendPasswordResetEmail(email: emailController.text.trim());
      Fluttertoast.showToast(msg: "Password Reset Email Sent TO ${emailController.text}");
    } on FirebaseAuthException catch(e){
      Fluttertoast.showToast(msg: "${e.message}");
      Navigator.of(context).pop();
    }
    
  }
}