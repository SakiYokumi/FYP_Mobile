import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

class ManageComplaints extends StatefulWidget {
  const ManageComplaints({super.key});

  @override
  State<ManageComplaints> createState() => _ManageComplaintsState();
}

class _ManageComplaintsState extends State<ManageComplaints> {
  var inputText = "";
  List detail = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Complaints"),
      ),
      body: SafeArea(
        child: Column(children: [
          TextFormField(
            onChanged: (value) {
              setState(() {
                inputText = value;
              });
            },
            decoration: const InputDecoration(
              fillColor: Colors.white,
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(0)),
                  borderSide: BorderSide(color: Colors.blue)),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(0)),
                  borderSide: BorderSide(color: Colors.grey)),
              hintText: "Enter ID",
              hintStyle: TextStyle(fontSize: 15.0),
            ),
          ),
          Expanded(
              // ignore: avoid_unnecessary_containers
              child: Container(
            child: StreamBuilder(
              stream: inputText != ""
                  ? FirebaseFirestore.instance
                      .collection("complaint")
                      .where("id", isEqualTo: int.parse(inputText))
                      .where("isRead", isEqualTo: "no")
                      .where("isDeleted", isEqualTo: 'no')
                      .snapshots()
                  : FirebaseFirestore.instance
                      .collection("complaint")
                      .where("isRead", isEqualTo: "no")
                      .where("isDeleted", isEqualTo: 'no')
                      .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                    child: Text("Something went wrong"),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: Text("Loading"),
                  );
                }
                return ListView(
                  children:
                      snapshot.data!.docs.map((DocumentSnapshot document) {
                    Map<String, dynamic> data =
                        document.data() as Map<String, dynamic>;
                    return Container(
                      height: 150,
                      child: Card(
                        elevation: 5,
                        child: Column(
                          children: <Widget>[
                            ListTile(
                              isThreeLine: true,
                              title: Text(
                                  "Complaint ID : ${data["id"]} \t Property ID : ${data['pid']}"),
                              subtitle: convertTime(data),
                              leading: ConstrainedBox(
                                  constraints: const BoxConstraints(
                                    minWidth: 100,
                                    minHeight: 100,
                                    maxHeight: 120,
                                    maxWidth: 120,
                                  ),
                                  child: const Icon(Icons.warning,
                                      color: Colors.yellow, size: 40)),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: <Widget>[
                                TextButton(
                                  child: const Text(
                                    'Mark As Read',
                                    style: TextStyle(color: Colors.blue),
                                  ),
                                  onPressed: () async {
                                    CollectionReference ref = FirebaseFirestore
                                        .instance
                                        .collection("complaint");
                                    ref
                                        .doc(data['id'].toString())
                                        .update({"isRead": "yes"})
                                        .then((value) => Fluttertoast.showToast(
                                            msg: "Updated Successfully"))
                                        .catchError((e) =>
                                            Fluttertoast.showToast(
                                                msg: "Failed to update : $e"));
                                  },
                                ),
                                const SizedBox(width: 8),
                                TextButton(
                                  child: const Text(
                                    'Delete',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                  onPressed: () async {
                                    CollectionReference ref = FirebaseFirestore.instance.collection("complaint");
                                          ref.doc(data['id'].toString())
                                          .update({
                                            "isDeleted" : "yes"
                                          })
                                          .then((value) => Fluttertoast.showToast(msg: "Deleted Successfully"))
                                          .catchError((e) => Fluttertoast.showToast(msg: "Failed to update : $e"));
                                  },
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ))
        ]),
      ),
    );
  }

  convertTime(data) {
    DateTime dt;
    dt = (data['reportAt'] as Timestamp).toDate();
    var time = DateFormat('dd/MM/yyyy').format(dt);
    return Text("${data['content']}\nReport At : $time");
  }
}
