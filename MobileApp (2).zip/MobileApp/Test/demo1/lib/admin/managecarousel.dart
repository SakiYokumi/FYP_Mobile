import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ManageCaroasel extends StatefulWidget {
  const ManageCaroasel({super.key});

  @override
  State<ManageCaroasel> createState() => _ManageCaroaselState();
}

class _ManageCaroaselState extends State<ManageCaroasel> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Carousel-slider"),
      ),
      body: SafeArea(
          child: Column(
        children: [
          Expanded(
              // ignore: avoid_unnecessary_containers
              child: Container(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection("carousal-slider")
                  .where("isDeleted", isEqualTo: 'no')
                  .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                    child: Text("Something went wrong"),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: Text("Loading"),
                  );
                }
                return ListView(
                  children:
                      snapshot.data!.docs.map((DocumentSnapshot document) {
                    Map<String, dynamic> data =
                        document.data() as Map<String, dynamic>;
                    return Container(
                        padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 30,
                              child: Text(data['id'].toString()),
                            ),
                            Container(
                                color: Colors.red,
                                height: 200,
                                width: 300,
                                child: FittedBox(
                                  child: Image.network(
                                    data['img-path'],
                                    height: 200,
                                    width: 300,
                                    fit: BoxFit.fill,
                                  ),
                                )),
                            ElevatedButton(
                              onPressed: () {
                                _displayTextInputDialog(context, data['id']);
                              },
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.red),
                              child: Center(
                                child: Container(
                                    height: 200,
                                    child: const Icon(
                                      Icons.cancel,
                                      color: Colors.white,
                                    )),
                              ),
                            )
                          ],
                        ));
                  }).toList(),
                );
              },
            ),
          ))
        ],
      )),
    );
  }

  Future<void> _displayTextInputDialog(BuildContext context, int id) async {
    // print(action);
    // print(id);
    final textController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    //bool isObscured = true;
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Delete Carousel-slider'),
            content: Form(
              key: formKey,
              child: TextFormField(
                controller: textController,
                validator: (val) {
                  if (val == "") {
                    return "Enter code";
                  } else {
                    if (val != "1234") {
                      return "Invalid code";
                    } else {
                      return null;
                    }
                  }
                },
                decoration: InputDecoration(
                    labelText: "Enter Code (1234)",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    prefixIcon: const Icon(
                      Icons.lock,
                      color: Colors.grey,
                    ),
                    focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                          width: 1.0,
                          color: Colors.blue,
                        ),
                        borderRadius: BorderRadius.circular(10)),
                    fillColor: Colors.grey,
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),

                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )),
              ),
            ),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: const Text(
                  'CANCEL',
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () {
                  setState(() {
                    Navigator.pop(context);
                  });
                },
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: const Text(
                  'OK',
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () async {
                  setState(() {
                    if (formKey.currentState!.validate()) {
                      CollectionReference ref = FirebaseFirestore.instance
                          .collection("carousal-slider");
                      ref
                          .doc(id.toString())
                          .update({"isDeleted": "yes"})
                          .then((value) => Fluttertoast.showToast(
                              msg: "Deleted Successfully"))
                          .catchError((e) => Fluttertoast.showToast(
                              msg: "Failed to update : $e"));
                      

                      Navigator.pop(context);
                    }
                  });
                },
              ),
            ],
          );
        });
  }
}
