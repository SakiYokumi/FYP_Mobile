// ignore_for_file: use_build_context_synchronously

import 'package:demo1/admin/managecarousel.dart';
import 'package:demo1/admin/managecomplaints.dart';
import 'package:demo1/admin/manageproperty.dart';
import 'package:demo1/authenticate/loginpage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AdminMain extends StatefulWidget {
  const AdminMain({super.key});

  @override
  State<AdminMain> createState() => _AdminMainState();
}

class _AdminMainState extends State<AdminMain> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[50],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        title: const Text('Admin'),
        actions: [
          TextButton(
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.push(
                context, 
                MaterialPageRoute(builder: (context) => const LoginPage()),
              );
            }, 
            child: const Text("Logout", style: TextStyle(color: Colors.white),)
          )
        ],
      ),
      body: SafeArea(
          child: SizedBox(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> ManageComplaints()));
                  }, 
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(250, 80),
                  ),
                  child: 
                    Text(
                      "Complaints Receive".toUpperCase(),
                    )
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> ManageProperty()));
                  }, 
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(250, 80),
                  ),
                  child: 
                    Text(
                      "Manage Property".toUpperCase(),
                    )
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ElevatedButton(
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> ManageCaroasel()));
                  }, 
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(250, 80),
                  ),
                  child: 
                    Text('Manage Carousel Slider'.toUpperCase()),
                  ),
              )
            ],
        ),
      )),
    );
  }
}
