import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class ManageProperty extends StatefulWidget {
  const ManageProperty({super.key});

  @override
  State<ManageProperty> createState() => _ManagePropertyState();
}

class _ManagePropertyState extends State<ManageProperty> {
  var inputText = "";
  List detail = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Property"),
      ),
      body: SafeArea(
          child: Column(
        children: [
          TextFormField(
            onChanged: (value) {
              setState(() {
                inputText = value;
              });
            },
            decoration: const InputDecoration(
              fillColor: Colors.white,
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(0)),
                  borderSide: BorderSide(color: Colors.blue)),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(0)),
                  borderSide: BorderSide(color: Colors.grey)),
              hintText: "Enter Property ID",
              hintStyle: TextStyle(fontSize: 15.0),
            ),
          ),
          Expanded(
              // ignore: avoid_unnecessary_containers
              child: Container(
            child: StreamBuilder(
              stream: inputText != ""
                  ? FirebaseFirestore.instance
                      .collection("Property")
                      .where("pid", isEqualTo: inputText)
                      .where("isDeleted", isEqualTo: 'no')
                      .snapshots()
                  : FirebaseFirestore.instance
                      .collection("Property")
                      .where("isDeleted", isEqualTo: 'no')
                      .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return const Center(
                    child: Text("Something went wrong"),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: Text("Loading"),
                  );
                }
                return ListView(
                  children:
                      snapshot.data!.docs.map((DocumentSnapshot document) {
                    Map<String, dynamic> data =
                        document.data() as Map<String, dynamic>;
                    return Container(
                      height: 130,
                      child: Card(
                        elevation: 5,
                        child: Column(
                          children: <Widget>[
                            ListTile(
                              title: Text("Property ID : ${data["pid"]}"),
                              subtitle: Text(
                                  "${data["address"]},${data["street"]},${data["city"]},${data["state"]}"),
                              leading: ConstrainedBox(
                                constraints: const BoxConstraints(
                                  minWidth: 100,
                                  minHeight: 100,
                                  maxHeight: 120,
                                  maxWidth: 120,
                                ),
                                child: Image.network(
                                  data['property-img'][0],
                                  fit: BoxFit.fill,
                                ),
                              ),
                              // leading: Image.network(data['property-img'][0]),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: <Widget>[
                                TextButton(
                                  child: const Text(
                                    'Add to carousel slider',
                                    style: TextStyle(color: Colors.blue),
                                  ),
                                  onPressed: () async {
                                    QuerySnapshot qn = await FirebaseFirestore
                                        .instance
                                        .collection("carousal-slider")
                                        .where('pid',
                                            isEqualTo: int.parse(data['pid']))
                                        .where("isDeleted", isEqualTo: "no")
                                        .get();

                                    if (qn.docs.isNotEmpty) {
                                      Fluttertoast.showToast(
                                          msg:
                                              "Already exist in carousel-slider");
                                    } else {
                                      // ignore: use_build_context_synchronously
                                      _displayTextInputDialog(
                                          context,
                                          data['pid'].toString(),
                                          "Add",
                                          data['property-img'][0]);
                                    }
                                  },
                                ),
                                const SizedBox(width: 8),
                                data["isBlocked"] == "no"
                                    ? TextButton(
                                        child: const Text(
                                          'Block',
                                          style: TextStyle(color: Colors.red),
                                        ),
                                        onPressed: () async {
                                          _displayTextInputDialog(
                                              context,
                                              data['pid'].toString(),
                                              "Block",
                                              data['property-img'][0]);
                                          // CollectionReference ref = FirebaseFirestore.instance.collection("Property");
                                          // ref.doc(data['pid'].toString())
                                          // .update({
                                          //   "isBlocked" : "yes"
                                          // })
                                          // .then((value) => Fluttertoast.showToast(msg: "Blocked Successfully"))
                                          // .catchError((e) => Fluttertoast.showToast(msg: "Failed to update : $e"));
                                        },
                                      )
                                    : TextButton(
                                        child: const Text(
                                          'Unblock',
                                          style: TextStyle(color: Colors.red),
                                        ),
                                        onPressed: () async {
                                          _displayTextInputDialog(
                                              context,
                                              data['pid'].toString(),
                                              "Unblock",
                                              data['property-img'][0]);
                                          // CollectionReference ref = FirebaseFirestore.instance.collection("Property");
                                          // ref.doc(data['pid'].toString())
                                          // .update({
                                          //   "isBlocked" : "no"
                                          // })
                                          // .then((value) => Fluttertoast.showToast(msg: "Unblocked Successfully"))
                                          // .catchError((e) => Fluttertoast.showToast(msg: "Failed to update : $e"));
                                        },
                                      ),
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ))
        ],
      )),
    );
  }

  Future<void> _displayTextInputDialog(
      BuildContext context, id, action, link) async {
    // print(action);
    // print(id);
    final textController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    //bool isObscured = true;
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Block Property'),
            content: Form(
              key: formKey,
              child: TextFormField(
                controller: textController,
                validator: (val) {
                  if (val == "") {
                    return "Enter code";
                  } else {
                    if (val != "1234") {
                      return "Invalid code";
                    } else {
                      return null;
                    }
                  }
                },
                decoration: InputDecoration(
                    labelText: "Enter Code (1234)",
                    focusColor: Colors.white,
                    border: const OutlineInputBorder(),
                    prefixIcon: const Icon(
                      Icons.lock,
                      color: Colors.grey,
                    ),
                    focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                          width: 1.0,
                          color: Colors.blue,
                        ),
                        borderRadius: BorderRadius.circular(10)),
                    fillColor: Colors.grey,
                    hintStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    ),

                    //create label
                    labelStyle: const TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      fontFamily: "verdana_regular",
                    )),
              ),
            ),
            actions: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: const Text(
                  'CANCEL',
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () {
                  setState(() {
                    Navigator.pop(context);
                  });
                },
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: const Text(
                  'OK',
                  style: TextStyle(color: Colors.white),
                ),
                onPressed: () async {
                  setState(() {
                    if (formKey.currentState!.validate()) {
                      if (action == "Unblock") {
                        //print("Unblocked");
                        CollectionReference ref =
                            FirebaseFirestore.instance.collection("Property");
                        ref
                            .doc(id)
                            .update({"isBlocked": "no"})
                            .then((value) => Fluttertoast.showToast(
                                msg: "Unblocked Successfully"))
                            .catchError((e) => Fluttertoast.showToast(
                                msg: "Failed to update : $e"));
                      } else if (action == "Block") {
                        //print("Blocked");
                        CollectionReference ref =
                            FirebaseFirestore.instance.collection("Property");
                        ref
                            .doc(id)
                            .update({"isBlocked": "yes"})
                            .then((value) => Fluttertoast.showToast(
                                msg: "Blocked Successfully"))
                            .catchError((e) => Fluttertoast.showToast(
                                msg: "Failed to update : $e"));
                      } else if (action == "Add") {
                        insertSlide(id, action, link);
                      }
                      // ignore: use_build_context_synchronously
                      Navigator.pop(context);
                    }
                  });
                },
              ),
            ],
          );
        });
  }

  void insertSlide(id, action, link) async {
    QuerySnapshot qn =
        await FirebaseFirestore.instance.collection("carousal-slider").get();
    List<DocumentSnapshot> _doc = qn.docs;
    int num = _doc.length + 1;
    CollectionReference ref =
        FirebaseFirestore.instance.collection("carousal-slider");
    await ref.doc(num.toString()).set({
      "id": num,
      "img-path": link.toString(),
      "isDeleted": "no",
      "pid": int.parse(id)
    });
  }
}
